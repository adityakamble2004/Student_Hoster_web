<?php
require_once __DIR__ . '/../includes/auth_helper.php';
require_once __DIR__ . '/../includes/dashboard_layout.php';
requireRole(['admin']);
$user = currentUser();
$db   = getDB();
$tab  = $_GET['tab'] ?? 'home';

// ── System-wide stats ─────────────────────────────────────
$totalUsers       = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalStudents    = $db->query("SELECT COUNT(*) FROM users WHERE role='student'")->fetchColumn();
$totalRecruiters  = $db->query("SELECT COUNT(*) FROM users WHERE role='recruiter'")->fetchColumn();
$totalModerators  = $db->query("SELECT COUNT(*) FROM users WHERE role='moderator'")->fetchColumn();
$totalPortfolios  = $db->query("SELECT COUNT(*) FROM portfolios")->fetchColumn();
$activePortfolios = $db->query("SELECT COUNT(*) FROM portfolios WHERE status='active'")->fetchColumn();
$pendingPortfolios= $db->query("SELECT COUNT(*) FROM portfolios WHERE status='pending'")->fetchColumn();
$totalStorageMB   = $db->query("SELECT COALESCE(SUM(used_mb),0) FROM storage_usage")->fetchColumn();

// ── Handle POST ───────────────────────────────────────────
$flash = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'create_user') {
        $name  = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $pwd   = $_POST['password'] ?? '';
        $role  = $_POST['role'] ?? 'moderator';
        if (!in_array($role, ['moderator','admin','recruiter','student'])) $role = 'moderator';
        if (!$name || !$email || !$pwd) {
            $flash = 'error:All fields are required.';
        } else {
            $result = registerUser($name,$email,$pwd,$role);
            if ($result['success']) {
                // Admin can create any role — update it
                $db->prepare("UPDATE users SET role=? WHERE email=?")->execute([$role,$email]);
                $flash = 'success:User created successfully!';
                logActivity($user['id'],'admin_create_user',"Created $role: $email");
            } else {
                $flash = 'error:'.$result['message'];
            }
        }
    }

    if ($action === 'change_role') {
        $uid  = (int)$_POST['user_id'];
        $role = $_POST['new_role'] ?? '';
        if (in_array($role, ['student','recruiter','moderator','admin']) && $uid !== $user['id']) {
            $db->prepare("UPDATE users SET role=? WHERE id=?")->execute([$role,$uid]);
            logActivity($user['id'],'admin_change_role',"Changed user $uid to $role");
            $flash = 'success:Role updated.';
        }
    }

    if ($action === 'toggle_user_status') {
        $uid = (int)$_POST['user_id'];
        if ($uid !== $user['id']) {
            $cur = $db->query("SELECT status FROM users WHERE id=$uid")->fetchColumn();
            $new = $cur==='active' ? 'suspended' : 'active';
            $db->prepare("UPDATE users SET status=? WHERE id=?")->execute([$new,$uid]);
            logActivity($user['id'],'admin_toggle_status',"Set user $uid to $new");
            $flash = 'success:User status updated.';
        }
    }

    if ($action === 'delete_user') {
        $uid = (int)$_POST['user_id'];
        if ($uid !== $user['id']) {
            $db->prepare("DELETE FROM users WHERE id=?")->execute([$uid]);
            logActivity($user['id'],'admin_delete_user',"Deleted user $uid");
            $flash = 'success:User deleted.';
        }
    }

    if ($action === 'update_storage') {
        $sid   = (int)$_POST['student_id'];
        $limit = (int)$_POST['new_limit'];
        if ($limit >= 50 && $limit <= 10240) {
            $db->prepare("UPDATE storage_usage SET limit_mb=? WHERE student_id=?")->execute([$limit,$sid]);
            $flash = 'success:Storage limit updated.';
        }
    }
}

// ── Fetch users ───────────────────────────────────────────
$search    = trim($_GET['search'] ?? '');
$roleFil   = $_GET['role_filter'] ?? '';
$where     = '1=1';
$params    = [];
if ($search)  { $where .= " AND (u.name LIKE ? OR u.email LIKE ?)"; $params[]="%$search%"; $params[]="%$search%"; }
if ($roleFil) { $where .= " AND u.role = ?"; $params[] = $roleFil; }
$usersQuery = $db->prepare("SELECT u.*, su.used_mb, su.limit_mb FROM users u LEFT JOIN storage_usage su ON u.id=su.student_id WHERE $where ORDER BY u.created_at DESC LIMIT 100");
$usersQuery->execute($params);
$usersList = $usersQuery->fetchAll();

// ── Storage list ──────────────────────────────────────────
$storageList = $db->query("
    SELECT u.id,u.name,u.email,su.used_mb,su.limit_mb,
           (SELECT COUNT(*) FROM portfolios p WHERE p.student_id=u.id) as portfolio_count
    FROM users u JOIN storage_usage su ON u.id=su.student_id
    ORDER BY su.used_mb DESC")->fetchAll();

// ── Logs ──────────────────────────────────────────────────
$logs = $db->query("SELECT l.*,u.name as user_name FROM activity_logs l LEFT JOIN users u ON l.user_id=u.id ORDER BY l.created_at DESC LIMIT 100")->fetchAll();

$pageTitles = ['home'=>'Admin Dashboard','users'=>'User Management','portfolios'=>'All Portfolios','storage'=>'Storage Management','logs'=>'Activity Logs','settings'=>'Settings'];
dashboardOpen($pageTitles[$tab] ?? 'Admin Dashboard', $user);

if ($flash) {
    [$ft,$fm] = str_starts_with($flash,'error:') ? ['danger',substr($flash,6)] : ['success',str_replace('success:','',$flash)];
    echo "<script>document.addEventListener('DOMContentLoaded',()=>toast(".json_encode($fm).",".json_encode($ft)."))</script>";
}
?>

<!-- ── HOME ──────────────────────────────────────────────── -->
<?php if ($tab === 'home'): ?>
<div class="stats-grid">
  <div class="stat-card" style="--card-color:#EF4444">
    <div class="stat-icon">👥</div>
    <div class="stat-label">Total Users</div>
    <div class="stat-value" data-count="<?= $totalUsers ?>"><?= $totalUsers ?></div>
    <div class="stat-change">🎓 <?= $totalStudents ?> students · 💼 <?= $totalRecruiters ?> recruiters · 🛡 <?= $totalModerators ?> mods</div>
  </div>
  <div class="stat-card" style="--card-color:#6C63FF">
    <div class="stat-icon">🗂️</div>
    <div class="stat-label">Portfolios</div>
    <div class="stat-value" data-count="<?= $totalPortfolios ?>"><?= $totalPortfolios ?></div>
    <div class="stat-change">✅ <?= $activePortfolios ?> active · ⏳ <?= $pendingPortfolios ?> pending</div>
  </div>
  <div class="stat-card" style="--card-color:#F59E0B">
    <div class="stat-icon">💾</div>
    <div class="stat-label">Storage Used</div>
    <div class="stat-value"><?= round($totalStorageMB/1024, 1) ?> <span style="font-size:1rem">GB</span></div>
    <div class="stat-change">Across all students</div>
  </div>
  <div class="stat-card" style="--card-color:#10B981">
    <div class="stat-icon">🛡️</div>
    <div class="stat-label">Moderators</div>
    <div class="stat-value" data-count="<?= $totalModerators ?>"><?= $totalModerators ?></div>
    <div class="stat-change"><a href="#" onclick="openModal('createUserModal');return false" style="color:var(--primary);font-size:.82rem">+ Add moderator</a></div>
  </div>
</div>

<div class="grid-2">
  <!-- Users by role chart -->
  <div class="section">
    <div class="section-head"><span class="section-title">Users by Role</span></div>
    <div class="section-body">
      <canvas id="rolesChart" height="200"></canvas>
    </div>
  </div>

  <!-- Portfolio status chart -->
  <div class="section">
    <div class="section-head"><span class="section-title">Portfolio Status</span></div>
    <div class="section-body">
      <canvas id="statusChart" height="200"></canvas>
    </div>
  </div>
</div>

<!-- Recent activity -->
<div class="section">
  <div class="section-head">
    <span class="section-title">Recent Activity</span>
    <a href="?tab=logs" class="btn btn-ghost btn-sm">View All</a>
  </div>
  <div style="padding:0">
    <?php foreach (array_slice($logs,0,8) as $log): ?>
    <div style="display:flex;align-items:center;gap:12px;padding:.75rem 1.4rem;border-bottom:1px solid var(--border)">
      <div style="width:28px;height:28px;background:rgba(108,99,255,.12);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:.8rem">
        <?= ['login'=>'🔑','logout'=>'🚪','register'=>'✨','portfolio_upload'=>'⬆️','approve_portfolio'=>'✅','reject_portfolio'=>'❌','suspend_student'=>'🚫'][$log['action']] ?? '📋' ?>
      </div>
      <div style="flex:1;font-size:.82rem">
        <strong><?= htmlspecialchars($log['user_name'] ?? 'System') ?></strong>
        <span style="color:var(--muted)"> · <?= htmlspecialchars($log['action']) ?></span>
        <?php if ($log['details']): ?><span style="color:var(--muted)"> — <?= htmlspecialchars(substr($log['details'],0,60)) ?></span><?php endif; ?>
      </div>
      <span style="font-size:.75rem;color:var(--muted)"><?= timeAgo($log['created_at']) ?></span>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-count]').forEach(el => {
    const t = parseInt(el.dataset.count);
    let c = 0; const iv = setInterval(() => { c=Math.min(c+Math.max(1,Math.ceil(t/30)),t); el.textContent=c; if(c>=t)clearInterval(iv); }, 40);
  });

  const rolesCtx = document.getElementById('rolesChart');
  new Chart(rolesCtx, {
    type: 'doughnut',
    data: {
      labels: ['Students','Recruiters','Moderators','Admins'],
      datasets: [{ data: [<?= $totalStudents ?>,<?= $totalRecruiters ?>,<?= $totalModerators ?>,<?= $db->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn() ?>], backgroundColor:['#6C63FF','#10B981','#F59E0B','#EF4444'], borderWidth:0, hoverOffset:6 }]
    },
    options: { responsive:true, plugins:{ legend:{ position:'bottom', labels:{ color:'#6B6F80', padding:16, font:{size:12} } } }, cutout:'65%' }
  });

  const statusCtx = document.getElementById('statusChart');
  new Chart(statusCtx, {
    type: 'doughnut',
    data: {
      labels: ['Active','Pending','Rejected'],
      datasets: [{ data: [<?= $activePortfolios ?>,<?= $pendingPortfolios ?>,<?= $db->query("SELECT COUNT(*) FROM portfolios WHERE status='rejected'")->fetchColumn() ?>], backgroundColor:['#10B981','#F59E0B','#EF4444'], borderWidth:0, hoverOffset:6 }]
    },
    options: { responsive:true, plugins:{ legend:{ position:'bottom', labels:{ color:'#6B6F80', padding:16, font:{size:12} } } }, cutout:'65%' }
  });
});
</script>

<!-- ── USERS TAB ──────────────────────────────────────────── -->
<?php elseif ($tab === 'users'): ?>
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.25rem;flex-wrap:wrap;gap:10px">
  <form method="GET" style="display:contents">
    <input type="hidden" name="tab" value="users">
    <div class="filter-row">
      <div class="search-bar" style="flex:1;min-width:220px;max-width:300px">
        <svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        <input type="text" name="search" placeholder="Search name or email..." value="<?= htmlspecialchars($search) ?>">
      </div>
      <select class="form-select" name="role_filter" style="width:140px">
        <option value="">All Roles</option>
        <?php foreach (['student','recruiter','moderator','admin'] as $r): ?>
          <option value="<?= $r ?>" <?= $roleFil===$r?'selected':'' ?>><?= ucfirst($r) ?></option>
        <?php endforeach; ?>
      </select>
      <button type="submit" class="btn btn-primary btn-sm">Filter</button>
      <?php if ($search||$roleFil): ?><a href="?tab=users" class="btn btn-ghost btn-sm">Clear</a><?php endif; ?>
    </div>
  </form>
  <button onclick="openModal('createUserModal')" class="btn btn-primary btn-sm">+ Create User</button>
</div>

<div class="section">
  <div class="table-wrap">
    <table>
      <thead><tr><th>User</th><th>Role</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
      <tbody>
        <?php foreach ($usersList as $u): ?>
        <tr>
          <td>
            <div style="font-weight:500"><?= htmlspecialchars($u['name']) ?></div>
            <div style="font-size:.75rem;color:var(--muted)"><?= htmlspecialchars($u['email']) ?></div>
          </td>
          <td>
            <select class="form-select" style="width:130px;padding:.3rem .5rem;font-size:.8rem"
              onchange="changeRole(<?= $u['id'] ?>,this.value)" <?= $u['id']==$user['id']?'disabled':'' ?>>
              <?php foreach (['student','recruiter','moderator','admin'] as $r): ?>
                <option value="<?= $r ?>" <?= $u['role']===$r?'selected':'' ?>><?= ucfirst($r) ?></option>
              <?php endforeach; ?>
            </select>
          </td>
          <td><span class="badge badge-<?= $u['status']==='active'?'success':($u['status']==='suspended'?'danger':'warning') ?>"><?= $u['status'] ?></span></td>
          <td style="color:var(--muted);font-size:.82rem"><?= date('M j, Y', strtotime($u['created_at'])) ?></td>
          <td>
            <div style="display:flex;gap:6px">
              <?php if ($u['id'] != $user['id']): ?>
              <form method="POST" style="display:inline">
                <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                <input type="hidden" name="action" value="toggle_user_status">
                <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                <button class="btn btn-<?= $u['status']==='active'?'danger':'success' ?> btn-sm"><?= $u['status']==='active'?'Suspend':'Activate' ?></button>
              </form>
              <form method="POST" style="display:inline" onsubmit="return confirm('Delete this user permanently?')">
                <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                <input type="hidden" name="action" value="delete_user">
                <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                <button class="btn btn-ghost btn-sm">🗑️</button>
              </form>
              <?php else: ?>
                <span style="font-size:.75rem;color:var(--muted)">That's you</span>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($usersList)): ?>
          <tr><td colspan="5" style="text-align:center;color:var(--muted);padding:2rem">No users found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- ── PORTFOLIOS TAB ──────────────────────────────────────── -->
<?php elseif ($tab === 'portfolios'): ?>
<?php
$allPorts = $db->query("
    SELECT p.*, u.name as student_name
    FROM portfolios p JOIN users u ON p.student_id=u.id
    ORDER BY p.uploaded_at DESC LIMIT 100")->fetchAll();
?>
<div class="section">
  <div class="table-wrap">
    <table>
      <thead><tr><th>Title</th><th>Student</th><th>Size</th><th>Status</th><th>Views</th><th>Uploaded</th><th>Actions</th></tr></thead>
      <tbody>
        <?php foreach ($allPorts as $p): ?>
        <tr>
          <td style="font-weight:500;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars($p['title']) ?></td>
          <td style="font-size:.85rem;color:var(--muted)"><?= htmlspecialchars($p['student_name']) ?></td>
          <td style="font-size:.82rem;color:var(--muted)"><?= round($p['size_mb'],1) ?> MB</td>
          <td><span class="badge badge-<?= $p['status']==='active'?'success':($p['status']==='pending'?'warning':'danger') ?>"><?= $p['status'] ?></span></td>
          <td style="font-size:.82rem"><?= $p['views'] ?></td>
          <td style="font-size:.78rem;color:var(--muted)"><?= timeAgo($p['uploaded_at']) ?></td>
          <td>
            <?php if ($p['status']==='active'): ?>
              <a href="<?= htmlspecialchars($p['public_url']) ?>" target="_blank" class="btn btn-ghost btn-sm">View</a>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- ── STORAGE TAB ────────────────────────────────────────── -->
<?php elseif ($tab === 'storage'): ?>
<div class="stats-grid" style="margin-bottom:1.5rem">
  <div class="stat-card" style="--card-color:#F59E0B">
    <div class="stat-label">Total Used</div>
    <div class="stat-value"><?= round($totalStorageMB/1024,1) ?> <span style="font-size:1rem">GB</span></div>
  </div>
  <div class="stat-card" style="--card-color:#6C63FF">
    <div class="stat-label">Students with Storage</div>
    <div class="stat-value"><?= count($storageList) ?></div>
  </div>
  <div class="stat-card" style="--card-color:#10B981">
    <div class="stat-label">Avg. Used per Student</div>
    <div class="stat-value"><?= count($storageList)>0 ? round($totalStorageMB/count($storageList),1) : 0 ?> <span style="font-size:1rem">MB</span></div>
  </div>
</div>
<div class="section">
  <div class="table-wrap">
    <table>
      <thead><tr><th>Student</th><th>Used</th><th>Limit</th><th>Usage</th><th>Portfolios</th><th>Actions</th></tr></thead>
      <tbody>
        <?php foreach ($storageList as $s): $pct = min(100,round(($s['used_mb']/$s['limit_mb'])*100)); ?>
        <tr>
          <td>
            <div style="font-weight:500"><?= htmlspecialchars($s['name']) ?></div>
            <div style="font-size:.75rem;color:var(--muted)"><?= htmlspecialchars($s['email']) ?></div>
          </td>
          <td style="font-size:.85rem"><?= round($s['used_mb'],1) ?> MB</td>
          <td style="font-size:.85rem;color:var(--muted)"><?= $s['limit_mb'] ?> MB</td>
          <td style="min-width:100px">
            <div style="display:flex;align-items:center;gap:8px">
              <div class="progress-bar" style="flex:1">
                <div class="progress-fill" style="width:<?= $pct ?>%;background:<?= $pct>85?'var(--danger)':($pct>60?'var(--warning)':'var(--primary)') ?>"></div>
              </div>
              <span style="font-size:.75rem;color:var(--muted)"><?= $pct ?>%</span>
            </div>
          </td>
          <td style="font-size:.85rem"><?= $s['portfolio_count'] ?></td>
          <td>
            <button onclick="openStorageModal(<?= $s['id'] ?>,<?= $s['limit_mb'] ?>)" class="btn btn-ghost btn-sm">✏️ Edit Limit</button>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- ── LOGS TAB ───────────────────────────────────────────── -->
<?php elseif ($tab === 'logs'): ?>
<div class="section">
  <div class="table-wrap">
    <table>
      <thead><tr><th>User</th><th>Action</th><th>Details</th><th>IP</th><th>Time</th></tr></thead>
      <tbody>
        <?php foreach ($logs as $log): ?>
        <tr>
          <td style="font-size:.85rem"><?= htmlspecialchars($log['user_name']??'System') ?></td>
          <td><span class="badge badge-info" style="font-family:var(--font-mono)"><?= htmlspecialchars($log['action']) ?></span></td>
          <td style="color:var(--muted);font-size:.82rem"><?= htmlspecialchars(substr($log['details']??'-',0,80)) ?></td>
          <td style="color:var(--muted);font-size:.78rem;font-family:var(--font-mono)"><?= htmlspecialchars($log['ip_address']) ?></td>
          <td style="color:var(--muted);font-size:.78rem"><?= timeAgo($log['created_at']) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- ── SETTINGS TAB ──────────────────────────────────────── -->
<?php elseif ($tab === 'settings'): ?>
<div style="max-width:600px">
  <div class="section">
    <div class="section-head"><span class="section-title">⚙️ Platform Settings</span></div>
    <div class="section-body">
      <div style="display:grid;gap:16px">
        <div style="display:flex;justify-content:space-between;align-items:center;padding:.9rem;background:rgba(255,255,255,.03);border-radius:10px;border:1px solid var(--border)">
          <div><div style="font-weight:500;font-size:.9rem">Default Student Storage Limit</div><div style="font-size:.8rem;color:var(--muted)">Applied to new students on registration</div></div>
          <span style="font-family:'Syne',sans-serif;font-weight:700"><?= MAX_STORAGE_MB ?> MB</span>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center;padding:.9rem;background:rgba(255,255,255,.03);border-radius:10px;border:1px solid var(--border)">
          <div><div style="font-weight:500;font-size:.9rem">Max ZIP Upload Size</div><div style="font-size:.8rem;color:var(--muted)">Maximum size per portfolio upload</div></div>
          <span style="font-family:'Syne',sans-serif;font-weight:700"><?= MAX_ZIP_SIZE_MB ?> MB</span>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center;padding:.9rem;background:rgba(255,255,255,.03);border-radius:10px;border:1px solid var(--border)">
          <div><div style="font-weight:500;font-size:.9rem">Max Files in ZIP</div><div style="font-size:.8rem;color:var(--muted)">Prevents zip bomb attacks</div></div>
          <span style="font-family:'Syne',sans-serif;font-weight:700"><?= MAX_ZIP_FILES ?></span>
        </div>
        <div style="padding:.9rem;background:rgba(255,255,255,.03);border-radius:10px;border:1px solid var(--border)">
          <div style="font-weight:500;font-size:.9rem;margin-bottom:.3rem">Platform Version</div>
          <div style="font-size:.8rem;color:var(--muted)">PortfolioHost v<?= APP_VERSION ?> — Edit config/config.php to change settings</div>
        </div>
      </div>
    </div>
  </div>

  <div class="section">
    <div class="section-head"><span class="section-title">⚡ Quick Actions</span></div>
    <div class="section-body" style="display:grid;gap:10px">
      <a href="?tab=users" class="btn btn-ghost">👥 Manage All Users</a>
      <a href="<?= APP_URL ?>/dashboard/moderator.php?tab=pending" class="btn btn-ghost">⏳ Review Pending Portfolios</a>
      <a href="?tab=storage" class="btn btn-ghost">💾 Manage Storage</a>
      <a href="?tab=logs" class="btn btn-ghost">📋 View Activity Logs</a>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- Create User Modal -->
<div class="modal-overlay" id="createUserModal">
  <div class="modal">
    <div class="modal-title">➕ Create New User</div>
    <form method="POST">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
      <input type="hidden" name="action" value="create_user">
      <div class="form-group">
        <label class="form-label">Full Name</label>
        <input type="text" class="form-input" name="name" placeholder="Full Name" required>
      </div>
      <div class="form-group">
        <label class="form-label">Email</label>
        <input type="email" class="form-input" name="email" placeholder="email@example.com" required>
      </div>
      <div class="form-group">
        <label class="form-label">Password</label>
        <input type="password" class="form-input" name="password" placeholder="Minimum 8 characters" required>
      </div>
      <div class="form-group">
        <label class="form-label">Role</label>
        <select class="form-select" name="role">
          <option value="moderator">Moderator</option>
          <option value="admin">Admin</option>
          <option value="recruiter">Recruiter</option>
          <option value="student">Student</option>
        </select>
      </div>
      <div class="modal-footer">
        <button type="button" onclick="closeModal('createUserModal')" class="btn btn-ghost">Cancel</button>
        <button type="submit" class="btn btn-primary">Create User</button>
      </div>
    </form>
  </div>
</div>

<!-- Storage Edit Modal -->
<div class="modal-overlay" id="storageModal">
  <div class="modal">
    <div class="modal-title">💾 Edit Storage Limit</div>
    <form method="POST">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
      <input type="hidden" name="action" value="update_storage">
      <input type="hidden" name="student_id" id="storStudentId">
      <div class="form-group">
        <label class="form-label">New Storage Limit (MB)</label>
        <input type="number" class="form-input" name="new_limit" id="storNewLimit" min="50" max="10240" placeholder="200">
      </div>
      <div class="modal-footer">
        <button type="button" onclick="closeModal('storageModal')" class="btn btn-ghost">Cancel</button>
        <button type="submit" class="btn btn-primary">Update Limit</button>
      </div>
    </form>
  </div>
</div>

<script>
function openStorageModal(studentId, currentLimit) {
  document.getElementById('storStudentId').value = studentId;
  document.getElementById('storNewLimit').value = currentLimit;
  openModal('storageModal');
}
function changeRole(userId, newRole) {
  if (!confirm(`Change this user's role to ${newRole}?`)) { location.reload(); return; }
  const f = document.createElement('form');
  f.method = 'POST';
  f.innerHTML = `
    <input name="csrf_token" value="<?= csrfToken() ?>">
    <input name="action" value="change_role">
    <input name="user_id" value="${userId}">
    <input name="new_role" value="${newRole}">
  `;
  document.body.appendChild(f);
  f.submit();
}
</script>
<?php dashboardClose(); ?>
