<?php
require_once __DIR__ . '/../includes/auth_helper.php';
require_once __DIR__ . '/../includes/dashboard_layout.php';
requireRole(['student']);
$user = currentUser();
$db   = getDB();
$tab  = $_GET['tab'] ?? 'home';

// ── Fetch student data ────────────────────────────────────
$storage = $db->prepare("SELECT used_mb, limit_mb FROM storage_usage WHERE student_id = ?");
$storage->execute([$user['id']]);
$stor = $storage->fetch() ?: ['used_mb'=>0,'limit_mb'=>200];

$portfolios = $db->prepare("SELECT * FROM portfolios WHERE student_id = ? ORDER BY uploaded_at DESC");
$portfolios->execute([$user['id']]);
$myPortfolios = $portfolios->fetchAll();

$totalViews = array_sum(array_column($myPortfolios, 'views'));
$active     = count(array_filter($myPortfolios, fn($p) => $p['status']==='active'));
$pending    = count(array_filter($myPortfolios, fn($p) => $p['status']==='pending'));

$profile = $db->prepare("SELECT * FROM student_profiles WHERE student_id = ?");
$profile->execute([$user['id']]);
$myProfile = $profile->fetch() ?: [];

$notifications = $db->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 20");
$notifications->execute([$user['id']]);
$notifs = $notifications->fetchAll();

// ── Handle POST actions ───────────────────────────────────
$flash = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'update_profile') {
        $bio     = trim($_POST['bio'] ?? '');
        $skills  = trim($_POST['skills'] ?? '');
        $college = trim($_POST['college'] ?? '');
        $grad    = trim($_POST['grad_year'] ?? '');
        $github  = trim($_POST['github_url'] ?? '');
        $linkedin= trim($_POST['linkedin_url'] ?? '');
        $db->prepare("UPDATE student_profiles SET bio=?,skills=?,college=?,grad_year=?,github_url=?,linkedin_url=? WHERE student_id=?")
           ->execute([$bio,$skills,$college,$grad ?: null,$github,$linkedin,$user['id']]);
        $flash = 'Profile updated successfully!';
        $tab = 'profile';
        // Reload profile
        $profile->execute([$user['id']]);
        $myProfile = $profile->fetch() ?: [];
    }

    if ($action === 'upload_portfolio') {
        $title = trim($_POST['title'] ?? '');
        $desc  = trim($_POST['description'] ?? '');
        $tags  = trim($_POST['tags'] ?? '');

        if (!$title) {
            $flash = 'error:Portfolio title is required.';
            $tab   = 'upload';
        } elseif (!isset($_FILES['zipfile']) || $_FILES['zipfile']['error'] !== UPLOAD_ERR_OK) {
            $flash = 'error:Please select a ZIP file.';
            $tab   = 'upload';
        } else {
            $zipFile  = $_FILES['zipfile'];
            $sizeMB   = $zipFile['size'] / (1024 * 1024);

            // Validate ZIP
            if ($zipFile['type'] !== 'application/zip' && pathinfo($zipFile['name'], PATHINFO_EXTENSION) !== 'zip') {
                $flash = 'error:Only .zip files are allowed.';
                $tab   = 'upload';
            } elseif ($sizeMB > MAX_ZIP_SIZE_MB) {
                $flash = 'error:File too large. Maximum allowed is ' . MAX_ZIP_SIZE_MB . 'MB.';
                $tab   = 'upload';
            } elseif (($stor['used_mb'] + $sizeMB) > $stor['limit_mb']) {
                $flash = 'error:Not enough storage space. You have ' . round($stor['limit_mb'] - $stor['used_mb'], 1) . 'MB remaining.';
                $tab   = 'upload';
            } else {
                // Security: open zip and check filenames
                $zip = new ZipArchive();
                if ($zip->open($zipFile['tmp_name']) === true) {
                    $safe = true;
                    if ($zip->numFiles > MAX_ZIP_FILES) {
                        $safe = false;
                        $flash = 'error:ZIP contains too many files (max ' . MAX_ZIP_FILES . ').';
                    }
                    for ($i = 0; $i < $zip->numFiles && $safe; $i++) {
                        $fname = $zip->getNameIndex($i);
                        // Block path traversal
                        if (strpos($fname, '..') !== false || strpos($fname, "\0") !== false) {
                            $safe = false;
                            $flash = 'error:Invalid file path detected in ZIP. Rejected for security.';
                        }
                        // Block PHP execution
                        $ext = strtolower(pathinfo($fname, PATHINFO_EXTENSION));
                        if (in_array($ext, ['php','phtml','phar','php3','php4','php5'])) {
                            $safe = false;
                            $flash = 'error:ZIP contains PHP files which are not allowed.';
                        }
                    }
                    $zip->close();

                    if ($safe) {
                        // Extract to public folder
                        $folderName = 'p_' . $user['id'] . '_' . time();
                        $destPath   = __DIR__ . '/../public/portfolios/' . $folderName;
                        mkdir($destPath, 0755, true);

                        $zip2 = new ZipArchive();
                        $zip2->open($zipFile['tmp_name']);
                        $zip2->extractTo($destPath);
                        $zip2->close();

                        // Write security .htaccess into extracted folder
                        file_put_contents($destPath . '/.htaccess',
                            "php_flag engine off\nAddType text/plain .php .php3 .phtml .phar\n");

                        // Calculate actual extracted size
                        $extractedMB = array_sum(array_map('filesize',
                            array_filter(glob($destPath . '/*'), 'is_file'))) / (1024*1024);
                        $extractedMB = round($extractedMB, 2);

                        $publicUrl = APP_URL . '/public/portfolios/' . $folderName . '/index.html';

                        // Save to DB
                        $ins = $db->prepare("INSERT INTO portfolios (student_id,title,description,folder_path,public_url,size_mb,tags) VALUES (?,?,?,?,?,?,?)");
                        $ins->execute([$user['id'],$title,$desc,$destPath,$publicUrl,$extractedMB,$tags]);

                        // Update storage
                        $db->prepare("UPDATE storage_usage SET used_mb = used_mb + ? WHERE student_id = ?")
                           ->execute([$extractedMB, $user['id']]);

                        logActivity($user['id'], 'portfolio_upload', "Uploaded: $title");
                        $flash = 'success:Portfolio uploaded! It will be reviewed and activated shortly.';
                        $tab   = 'portfolios';
                    }
                    $tab = $safe ? 'portfolios' : 'upload';
                } else {
                    $flash = 'error:Could not open the ZIP file.';
                    $tab   = 'upload';
                }
            }
        }
        // Reload data
        $portfolios->execute([$user['id']]);
        $myPortfolios = $portfolios->fetchAll();
        $storage->execute([$user['id']]);
        $stor = $storage->fetch() ?: ['used_mb'=>0,'limit_mb'=>200];
    }

    if ($action === 'delete_portfolio') {
        $pid = (int)($_POST['portfolio_id'] ?? 0);
        $port = $db->prepare("SELECT * FROM portfolios WHERE id = ? AND student_id = ?");
        $port->execute([$pid, $user['id']]);
        $p = $port->fetch();
        if ($p) {
            // Delete folder
            if (is_dir($p['folder_path'])) {
                array_map('unlink', glob($p['folder_path'].'/*'));
                rmdir($p['folder_path']);
            }
            $db->prepare("DELETE FROM portfolios WHERE id = ?")->execute([$pid]);
            $db->prepare("UPDATE storage_usage SET used_mb = GREATEST(0, used_mb - ?) WHERE student_id = ?")
               ->execute([$p['size_mb'], $user['id']]);
            $flash = 'success:Portfolio deleted.';
            logActivity($user['id'], 'portfolio_delete', "Deleted: " . $p['title']);
        }
        $portfolios->execute([$user['id']]);
        $myPortfolios = $portfolios->fetchAll();
        $storage->execute([$user['id']]);
        $stor = $storage->fetch() ?: ['used_mb'=>0,'limit_mb'=>200];
        $tab = 'portfolios';
    }
}

$storPct = min(100, round(($stor['used_mb'] / max(1,$stor['limit_mb'])) * 100));
$pageTitles = ['home'=>'Dashboard','upload'=>'Upload Portfolio','portfolios'=>'My Portfolios','profile'=>'My Profile','notifications'=>'Notifications'];
dashboardOpen($pageTitles[$tab] ?? 'Dashboard', $user);
?>

<?php
// Flash message
[$flashType, $flashMsg] = str_starts_with($flash,'error:')
    ? ['danger', substr($flash,6)]
    : ($flash ? ['success', str_replace('success:','',$flash)] : [null,null]);
?>

<?php if ($flashMsg): ?>
<script>document.addEventListener('DOMContentLoaded',()=>toast(<?= json_encode($flashMsg) ?>,<?= json_encode($flashType) ?>))</script>
<?php endif; ?>

<!-- ── HOME TAB ───────────────────────────────────────────── -->
<?php if ($tab === 'home'): ?>

<div class="stats-grid">
  <div class="stat-card" style="--card-color:#6C63FF">
    <div class="stat-icon">🗂️</div>
    <div class="stat-label">Total Portfolios</div>
    <div class="stat-value" data-count="<?= count($myPortfolios) ?>"><?= count($myPortfolios) ?></div>
    <div class="stat-change"><?= $active ?> active &nbsp;·&nbsp; <?= $pending ?> pending</div>
  </div>
  <div class="stat-card" style="--card-color:#10B981">
    <div class="stat-icon">👁️</div>
    <div class="stat-label">Total Views</div>
    <div class="stat-value" data-count="<?= $totalViews ?>"><?= $totalViews ?></div>
    <div class="stat-change">Across all portfolios</div>
  </div>
  <div class="stat-card" style="--card-color:#F59E0B">
    <div class="stat-icon">💾</div>
    <div class="stat-label">Storage Used</div>
    <div class="stat-value"><?= round($stor['used_mb'],1) ?> <span style="font-size:1rem">MB</span></div>
    <div class="stat-change"><?= $storPct ?>% of <?= $stor['limit_mb'] ?>MB</div>
  </div>
  <div class="stat-card" style="--card-color:#3B82F6">
    <div class="stat-icon">🔔</div>
    <div class="stat-label">Notifications</div>
    <div class="stat-value"><?= count(array_filter($notifs, fn($n)=>!$n['is_read'])) ?></div>
    <div class="stat-change">Unread messages</div>
  </div>
</div>

<div class="grid-2">
  <div class="section">
    <div class="section-head">
      <span class="section-title">Storage Usage</span>
      <span style="font-size:.8rem;color:var(--muted)"><?= round($stor['used_mb'],1) ?> / <?= $stor['limit_mb'] ?> MB</span>
    </div>
    <div class="section-body">
      <div class="progress-bar" style="margin-bottom:0.75rem">
        <div class="progress-fill" id="storBar"
             style="width:0%;background:<?= $storPct>85?'var(--danger)':($storPct>60?'var(--warning)':'var(--primary)') ?>">
        </div>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:.8rem;color:var(--muted)">
        <span>Used: <strong style="color:var(--text)"><?= round($stor['used_mb'],1) ?> MB</strong></span>
        <span>Free: <strong style="color:var(--success)"><?= round($stor['limit_mb']-$stor['used_mb'],1) ?> MB</strong></span>
      </div>
      <div style="margin-top:1.25rem">
        <a href="?tab=upload" class="btn btn-primary btn-sm">⬆️ Upload New Portfolio</a>
      </div>
    </div>
  </div>

  <div class="section">
    <div class="section-head">
      <span class="section-title">Recent Portfolios</span>
      <a href="?tab=portfolios" class="btn btn-ghost btn-sm">View All</a>
    </div>
    <div class="section-body" style="padding:0">
      <?php if (empty($myPortfolios)): ?>
        <div style="padding:2rem;text-align:center;color:var(--muted)">
          <div style="font-size:2rem;margin-bottom:.5rem">📂</div>
          <div>No portfolios yet</div>
          <a href="?tab=upload" style="color:var(--primary);font-size:.85rem">Upload your first one →</a>
        </div>
      <?php else: ?>
        <?php foreach (array_slice($myPortfolios, 0, 4) as $p): ?>
        <div style="display:flex;align-items:center;gap:12px;padding:.85rem 1.2rem;border-bottom:1px solid var(--border)">
          <div style="flex:1;min-width:0">
            <div style="font-size:.875rem;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($p['title']) ?></div>
            <div style="font-size:.75rem;color:var(--muted)"><?= timeAgo($p['uploaded_at']) ?> &nbsp;·&nbsp; <?= round($p['size_mb'],1) ?> MB</div>
          </div>
          <span class="badge badge-<?= $p['status']==='active'?'success':($p['status']==='pending'?'warning':'danger') ?>"><?= $p['status'] ?></span>
        </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Recent activity chart -->
<div class="section">
  <div class="section-head"><span class="section-title">Portfolio Views (Last 7 Days)</span></div>
  <div class="section-body">
    <canvas id="viewsChart" height="80"></canvas>
  </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', () => {
  // Animate storage bar
  setTimeout(() => document.getElementById('storBar').style.width = '<?= $storPct ?>%', 100);

  // Animate count-up
  document.querySelectorAll('[data-count]').forEach(el => {
    const target = parseInt(el.dataset.count);
    let cur = 0, step = Math.ceil(target/30);
    const t = setInterval(() => { cur = Math.min(cur+step, target); el.textContent = cur; if(cur>=target) clearInterval(t); }, 40);
  });

  // Views chart
  new Chart(document.getElementById('viewsChart'), {
    type: 'line',
    data: {
      labels: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
      datasets: [{
        data: [0,0,0,0,0,0,0], // Real data would come from DB
        borderColor: '#6C63FF', backgroundColor: 'rgba(108,99,255,0.1)',
        fill: true, tension: 0.4, pointBackgroundColor: '#6C63FF', pointRadius: 4
      }]
    },
    options: {
      responsive: true, plugins: { legend: { display: false } },
      scales: {
        x: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#6B6F80' } },
        y: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#6B6F80', stepSize: 1, beginAtZero: true } }
      }
    }
  });
});
</script>

<!-- ── UPLOAD TAB ─────────────────────────────────────────── -->
<?php elseif ($tab === 'upload'): ?>
<div style="max-width:640px">
  <div class="section">
    <div class="section-head"><span class="section-title">Upload Portfolio ZIP</span></div>
    <div class="section-body">
      <form method="POST" enctype="multipart/form-data" id="uploadForm">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="action" value="upload_portfolio">

        <div class="form-group">
          <label class="form-label">Portfolio Title *</label>
          <input type="text" class="form-input" name="title" placeholder="e.g. My Web Developer Portfolio" required>
        </div>
        <div class="form-group">
          <label class="form-label">Description</label>
          <textarea class="form-textarea" name="description" placeholder="Short description of your portfolio..."></textarea>
        </div>
        <div class="form-group">
          <label class="form-label">Tags <span style="text-transform:none;font-weight:400;color:var(--muted)">(comma-separated)</span></label>
          <input type="text" class="form-input" name="tags" placeholder="react, nodejs, mongodb">
        </div>

        <div class="form-group">
          <label class="form-label">Portfolio ZIP File *</label>
          <div class="drop-zone" id="dropZone" onclick="document.getElementById('zipInput').click()">
            <div class="drop-zone-icon">📦</div>
            <div class="drop-zone-title" id="dropTitle">Drop your ZIP here or click to browse</div>
            <div class="drop-zone-sub" id="dropSub">Maximum <?= MAX_ZIP_SIZE_MB ?>MB · Must contain index.html · No PHP files</div>
          </div>
          <input type="file" id="zipInput" name="zipfile" accept=".zip" style="display:none" onchange="fileSelected(this)">
        </div>

        <!-- Upload progress -->
        <div id="uploadProgress" style="display:none;margin-bottom:1rem">
          <div style="font-size:.85rem;color:var(--muted);margin-bottom:.4rem">Uploading...</div>
          <div class="progress-bar"><div class="progress-fill" id="uploadBar" style="width:0%;background:var(--primary)"></div></div>
        </div>

        <div style="display:flex;gap:10px;align-items:center">
          <button type="submit" class="btn btn-primary" id="uploadBtn">⬆️ Upload Portfolio</button>
          <span style="font-size:.8rem;color:var(--muted)">Available: <?= round($stor['limit_mb']-$stor['used_mb'],1) ?> MB</span>
        </div>
      </form>
    </div>
  </div>

  <div class="section">
    <div class="section-head"><span class="section-title">📋 Upload Rules</span></div>
    <div class="section-body">
      <div style="display:grid;gap:8px;font-size:.875rem">
        <div style="display:flex;gap:8px;align-items:flex-start"><span style="color:var(--success)">✓</span><span>Your ZIP must contain an <strong>index.html</strong> at the root level</span></div>
        <div style="display:flex;gap:8px;align-items:flex-start"><span style="color:var(--success)">✓</span><span>Maximum file size: <strong><?= MAX_ZIP_SIZE_MB ?> MB</strong></span></div>
        <div style="display:flex;gap:8px;align-items:flex-start"><span style="color:var(--success)">✓</span><span>Supported: HTML, CSS, JS, images, fonts</span></div>
        <div style="display:flex;gap:8px;align-items:flex-start"><span style="color:var(--danger)">✗</span><span>PHP files are not allowed (security reasons)</span></div>
        <div style="display:flex;gap:8px;align-items:flex-start"><span style="color:var(--danger)">✗</span><span>No path traversal (../../../) filenames</span></div>
        <div style="display:flex;gap:8px;align-items:flex-start"><span style="color:var(--warning)">⏳</span><span>Uploaded portfolios need moderator approval before going live</span></div>
      </div>
    </div>
  </div>
</div>
<script>
const dz = document.getElementById('dropZone');
dz.addEventListener('dragover', e => { e.preventDefault(); dz.classList.add('dragover'); });
dz.addEventListener('dragleave', () => dz.classList.remove('dragover'));
dz.addEventListener('drop', e => {
  e.preventDefault(); dz.classList.remove('dragover');
  const f = e.dataTransfer.files[0];
  if (f) { document.getElementById('zipInput').files = e.dataTransfer.files; fileSelected({files:[f]}); }
});
function fileSelected(inp) {
  const f = inp.files[0];
  if (!f) return;
  document.getElementById('dropTitle').textContent = f.name;
  document.getElementById('dropSub').textContent = (f.size/1024/1024).toFixed(2) + ' MB selected';
  dz.style.borderColor = 'var(--primary)';
}
document.getElementById('uploadForm').addEventListener('submit', function() {
  document.getElementById('uploadProgress').style.display = 'block';
  document.getElementById('uploadBtn').disabled = true;
  let w = 0;
  const iv = setInterval(() => {
    w = Math.min(w + Math.random()*15, 90);
    document.getElementById('uploadBar').style.width = w + '%';
    if (w >= 90) clearInterval(iv);
  }, 200);
});
</script>

<!-- ── PORTFOLIOS TAB ──────────────────────────────────────── -->
<?php elseif ($tab === 'portfolios'): ?>
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.25rem;flex-wrap:wrap;gap:10px">
  <div class="filter-row">
    <div class="search-bar">
      <svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
      <input type="text" placeholder="Search portfolios..." id="searchPortfolios" oninput="filterPortfolios()">
    </div>
  </div>
  <a href="?tab=upload" class="btn btn-primary btn-sm">+ Upload New</a>
</div>

<?php if (empty($myPortfolios)): ?>
  <div class="section"><div class="section-body" style="text-align:center;padding:3rem;color:var(--muted)">
    <div style="font-size:3rem;margin-bottom:1rem">📂</div>
    <div style="font-size:1rem;margin-bottom:.5rem">No portfolios yet</div>
    <a href="?tab=upload" class="btn btn-primary" style="margin-top:.75rem">Upload Your First Portfolio</a>
  </div></div>
<?php else: ?>
<div id="portfolioList" style="display:grid;gap:14px">
  <?php foreach ($myPortfolios as $p): ?>
  <div class="section portfolio-card" data-title="<?= htmlspecialchars(strtolower($p['title'])) ?>">
    <div class="section-body">
      <div style="display:flex;align-items:flex-start;gap:14px;flex-wrap:wrap">
        <div style="flex:1;min-width:0">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:.4rem;flex-wrap:wrap">
            <span style="font-family:'Syne',sans-serif;font-weight:700;font-size:1rem"><?= htmlspecialchars($p['title']) ?></span>
            <span class="badge badge-<?= $p['status']==='active'?'success':($p['status']==='pending'?'warning':'danger') ?>"><?= $p['status'] ?></span>
          </div>
          <?php if ($p['description']): ?>
            <div style="font-size:.875rem;color:var(--muted);margin-bottom:.6rem"><?= htmlspecialchars($p['description']) ?></div>
          <?php endif; ?>
          <div style="display:flex;gap:1.5rem;font-size:.78rem;color:var(--muted);flex-wrap:wrap">
            <span>📅 <?= date('M j, Y', strtotime($p['uploaded_at'])) ?></span>
            <span>💾 <?= round($p['size_mb'],1) ?> MB</span>
            <span>👁️ <?= $p['views'] ?> views</span>
            <?php if ($p['tags']): ?>
              <span>🏷️ <?= htmlspecialchars($p['tags']) ?></span>
            <?php endif; ?>
          </div>
          <?php if ($p['status']==='rejected' && $p['rejection_reason']): ?>
            <div style="margin-top:.6rem;padding:.5rem .75rem;background:rgba(239,68,68,0.08);border-radius:8px;font-size:.8rem;color:#FCA5A5">
              ⚠️ Rejected: <?= htmlspecialchars($p['rejection_reason']) ?>
            </div>
          <?php endif; ?>
        </div>
        <div style="display:flex;gap:8px;flex-shrink:0;align-items:flex-start">
          <?php if ($p['status']==='active'): ?>
            <a href="<?= htmlspecialchars($p['public_url']) ?>" target="_blank" class="btn btn-ghost btn-sm">🔗 View Live</a>
            <button onclick="copyLink('<?= htmlspecialchars($p['public_url']) ?>')" class="btn btn-ghost btn-sm">📋 Copy Link</button>
          <?php endif; ?>
          <form method="POST" style="display:inline" onsubmit="return confirm('Delete this portfolio?')">
            <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
            <input type="hidden" name="action" value="delete_portfolio">
            <input type="hidden" name="portfolio_id" value="<?= $p['id'] ?>">
            <button type="submit" class="btn btn-danger btn-sm">🗑️</button>
          </form>
        </div>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<script>
function filterPortfolios() {
  const q = document.getElementById('searchPortfolios').value.toLowerCase();
  document.querySelectorAll('.portfolio-card').forEach(c => {
    c.style.display = c.dataset.title.includes(q) ? '' : 'none';
  });
}
function copyLink(url) {
  navigator.clipboard.writeText(url).then(() => toast('Link copied to clipboard!'));
}
</script>
<?php endif; ?>

<!-- ── PROFILE TAB ────────────────────────────────────────── -->
<?php elseif ($tab === 'profile'): ?>
<div style="max-width:640px">
  <div class="section">
    <div class="section-head"><span class="section-title">My Profile</span></div>
    <div class="section-body">
      <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="action" value="update_profile">
        <div class="grid-2">
          <div class="form-group">
            <label class="form-label">College / University</label>
            <input type="text" class="form-input" name="college" placeholder="e.g. Savitribai Phule Pune University"
                   value="<?= htmlspecialchars($myProfile['college'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">Graduation Year</label>
            <input type="number" class="form-input" name="grad_year" min="2020" max="2035" placeholder="2026"
                   value="<?= htmlspecialchars($myProfile['grad_year'] ?? '') ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Skills <span style="text-transform:none;font-weight:400">(comma-separated)</span></label>
          <input type="text" class="form-input" name="skills" placeholder="PHP, MySQL, React, Node.js, Tailwind CSS"
                 value="<?= htmlspecialchars($myProfile['skills'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label class="form-label">Bio</label>
          <textarea class="form-textarea" name="bio" placeholder="Tell recruiters about yourself..."><?= htmlspecialchars($myProfile['bio'] ?? '') ?></textarea>
        </div>
        <div class="grid-2">
          <div class="form-group">
            <label class="form-label">GitHub URL</label>
            <input type="url" class="form-input" name="github_url" placeholder="https://github.com/yourname"
                   value="<?= htmlspecialchars($myProfile['github_url'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">LinkedIn URL</label>
            <input type="url" class="form-input" name="linkedin_url" placeholder="https://linkedin.com/in/yourname"
                   value="<?= htmlspecialchars($myProfile['linkedin_url'] ?? '') ?>">
          </div>
        </div>
        <button type="submit" class="btn btn-primary">💾 Save Profile</button>
      </form>
    </div>
  </div>
</div>

<!-- ── NOTIFICATIONS TAB ──────────────────────────────────── -->
<?php elseif ($tab === 'notifications'): ?>
<div style="max-width:640px">
  <div class="section">
    <div class="section-head">
      <span class="section-title">Notifications</span>
      <button onclick="markAllRead()" class="btn btn-ghost btn-sm">Mark all read</button>
    </div>
    <?php if (empty($notifs)): ?>
      <div class="section-body" style="text-align:center;color:var(--muted);padding:2.5rem">
        <div style="font-size:2rem;margin-bottom:.5rem">🔔</div>
        <div>No notifications yet</div>
      </div>
    <?php else: ?>
      <?php foreach ($notifs as $n): ?>
      <div style="display:flex;gap:12px;padding:.9rem 1.4rem;border-bottom:1px solid var(--border);<?= !$n['is_read']?'background:rgba(108,99,255,0.04)':'' ?>">
        <div style="margin-top:2px">
          <?= ['success'=>'✅','danger'=>'❌','warning'=>'⚠️','info'=>'ℹ️'][$n['type']] ?? 'ℹ️' ?>
        </div>
        <div style="flex:1">
          <div style="font-size:.875rem;font-weight:500;margin-bottom:2px"><?= htmlspecialchars($n['title']) ?></div>
          <div style="font-size:.82rem;color:var(--muted)"><?= htmlspecialchars($n['message']) ?></div>
          <div style="font-size:.75rem;color:var(--muted);margin-top:4px"><?= timeAgo($n['created_at']) ?></div>
        </div>
        <?php if (!$n['is_read']): ?>
          <div style="width:8px;height:8px;background:var(--primary);border-radius:50%;margin-top:4px;flex-shrink:0"></div>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>
<script>
function markAllRead() {
  fetch('', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body: 'action=mark_notifications&csrf_token=<?= csrfToken() ?>'
  }).then(() => location.reload());
}
</script>
<?php endif; ?>

<?php dashboardClose(); ?>
