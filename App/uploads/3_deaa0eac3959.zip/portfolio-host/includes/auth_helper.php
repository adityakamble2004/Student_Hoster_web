<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';

// ── Check if user is logged in ──────────────────────────────
function isLoggedIn(): bool {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// ── Require login or redirect ────────────────────────────────
function requireLogin(): void {
    if (!isLoggedIn()) {
        header('Location: ' . APP_URL . '/auth/login.php');
        exit;
    }
}

// ── Require specific role(s) ─────────────────────────────────
function requireRole(array $roles): void {
    requireLogin();
    if (!in_array($_SESSION['role'], $roles)) {
        header('Location: ' . APP_URL . '/auth/login.php?error=unauthorized');
        exit;
    }
}

// ── Get current user from session ────────────────────────────
function currentUser(): array {
    return [
        'id'     => $_SESSION['user_id']   ?? null,
        'name'   => $_SESSION['user_name'] ?? '',
        'email'  => $_SESSION['user_email']?? '',
        'role'   => $_SESSION['role']      ?? '',
        'avatar' => $_SESSION['avatar']    ?? null,
    ];
}

// ── Login: validate and set session ──────────────────────────
function loginUser(string $email, string $password): array {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE email = ? AND status != 'suspended' LIMIT 1");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password'])) {
        return ['success' => false, 'message' => 'Invalid email or password.'];
    }

    // Set session
    session_regenerate_id(true);
    $_SESSION['user_id']    = $user['id'];
    $_SESSION['user_name']  = $user['name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['role']       = $user['role'];
    $_SESSION['avatar']     = $user['avatar'];

    logActivity($user['id'], 'login', 'User logged in');

    $dashboards = ROLE_DASHBOARDS;
    return ['success' => true, 'redirect' => APP_URL . $dashboards[$user['role']]];
}

// ── Register new user ─────────────────────────────────────────
function registerUser(string $name, string $email, string $password, string $role): array {
    $allowedRoles = ['student', 'recruiter'];
    if (!in_array($role, $allowedRoles)) {
        return ['success' => false, 'message' => 'Invalid role selected.'];
    }

    $db = getDB();
    // Check email exists
    $check = $db->prepare("SELECT id FROM users WHERE email = ?");
    $check->execute([$email]);
    if ($check->fetch()) {
        return ['success' => false, 'message' => 'Email already registered.'];
    }

    $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    $stmt = $db->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
    $stmt->execute([$name, $email, $hash, $role]);
    $userId = $db->lastInsertId();

    // Create student profile and storage record
    if ($role === 'student') {
        $db->prepare("INSERT INTO student_profiles (student_id) VALUES (?)")->execute([$userId]);
        $db->prepare("INSERT INTO storage_usage (student_id) VALUES (?)")->execute([$userId]);
    }

    logActivity($userId, 'register', "New $role registered");
    return ['success' => true, 'message' => 'Account created! Please log in.'];
}

// ── Log activity ──────────────────────────────────────────────
function logActivity(?int $userId, string $action, string $details = ''): void {
    try {
        $db  = getDB();
        $ip  = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $db->prepare("INSERT INTO activity_logs (user_id, action, details, ip_address) VALUES (?,?,?,?)")
           ->execute([$userId, $action, $details, $ip]);
    } catch (Exception $e) { /* silent fail for logging */ }
}

// ── Send notification to user ─────────────────────────────────
function sendNotification(int $userId, string $title, string $message, string $type = 'info'): void {
    $db = getDB();
    $db->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?,?,?,?)")
       ->execute([$userId, $title, $message, $type]);
}

// ── Get unread notification count ────────────────────────────
function unreadNotifications(int $userId): int {
    $db   = getDB();
    $stmt = $db->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->execute([$userId]);
    return (int)$stmt->fetchColumn();
}

// ── CSRF helpers ──────────────────────────────────────────────
function csrfToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrf(): void {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== ($_SESSION['csrf_token'] ?? '')) {
        http_response_code(403);
        die('CSRF validation failed.');
    }
}

// ── Format file size ──────────────────────────────────────────
function formatSize(float $mb): string {
    if ($mb < 1) return round($mb * 1024, 1) . ' KB';
    return round($mb, 2) . ' MB';
}

// ── Time ago helper ───────────────────────────────────────────
function timeAgo(string $datetime): string {
    $diff = time() - strtotime($datetime);
    if ($diff < 60)     return 'just now';
    if ($diff < 3600)   return floor($diff/60) . 'm ago';
    if ($diff < 86400)  return floor($diff/3600) . 'h ago';
    return floor($diff/86400) . 'd ago';
}
