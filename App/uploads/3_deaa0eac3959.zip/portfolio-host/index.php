<?php
require_once __DIR__ . '/includes/auth_helper.php';

if (isLoggedIn()) {
    $dash = ROLE_DASHBOARDS[$_SESSION['role']] ?? '/auth/login.php';
    header('Location: ' . APP_URL . $dash); exit;
}
header('Location: ' . APP_URL . '/auth/login.php'); exit;
