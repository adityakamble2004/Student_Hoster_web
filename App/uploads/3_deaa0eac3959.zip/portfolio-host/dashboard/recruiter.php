<?php
require_once __DIR__ . '/../includes/auth_helper.php';
require_once __DIR__ . '/../includes/dashboard_layout.php';
requireRole(['recruiter']);
$user = currentUser();
$db   = getDB();
$tab  = $_GET['tab'] ?? 'home';

// ── Data ──────────────────────────────────────────────────
$totalPortfolios = $db->query("SELECT COUNT(*) FROM portfolios WHERE status='active' AND visibility='public'")->fetchColumn();
$totalStudents   = $db->query("SELECT COUNT(*) FROM users WHERE role='student' AND status='active'")->fetchColumn();

$bStmt = $db->prepare("SELECT COUNT(*) FROM bookmarks WHERE recruiter_id = ?");
$bStmt->execute([$user['id']]); $myBookmarks = $bStmt->fetchColumn();

// ── Handle POST ───────────────────────────────────────────
$flash = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = $_POST['action'] ?? '';
    if ($action === 'toggle_bookmark') {
        $pid  = (int)($_POST['portfolio_id'] ?? 0);
        $note = trim($_POST['note'] ?? '');
        $check = $db->prepare("SELECT id FROM bookmarks WHERE recruiter_id=? AND portfolio_id=?");
        $check->execute([$user['id'], $pid]);
        if ($check->fetch()) {
            $db->prepare("DELETE FROM bookmarks WHERE recruiter_id=? AND portfolio_id=?")->execute([$user['id'],$pid]);
            $flash = 'success:Bookmark removed.';
        } else {
            $db->prepare("INSERT INTO bookmarks (recruiter_id,portfolio_id,note) VALUES (?,?,?)")->execute([$user['id'],$pid,$note]);
            $flash = 'success:Portfolio bookmarked!';
        }
        $bStmt->execute([$user['id']]); $myBookmarks = $bStmt->fetchColumn();
    }
}

// ── Fetch portfolios for browse ───────────────────────────
$search    = trim($_GET['search'] ?? '');
$skillFil  = trim($_GET['skill'] ?? '');
$sortBy    = $_GET['sort'] ?? 'newest';

$whereClause = "p.status='active' AND p.visibility='public'";
$params = [];
if ($search) { $whereClause .= " AND (u.name LIKE ? OR p.title LIKE ? OR p.tags LIKE ?)"; $s="%$search%"; $params=array_merge($params,[$s,$s,$s]); }
if ($skillFil) { $whereClause .= " AND (p.tags LIKE ? OR sp.skills LIKE ?)"; $sf="%$skillFil%"; $params=array_merge($params,[$sf,$sf]); }
$order = match($sortBy) { 'views'=>'p.views DESC', 'name'=>'u.name ASC', default=>'p.uploaded_at DESC' };

$stmt = $db->prepare("
    SELECT p.*, u.name as student_name, u.email as student_email,
           sp.college, sp.skills, sp.github_url, sp.linkedin_url, sp.bio,
           (SELECT COUNT(*) FROM bookmarks b WHERE b.portfolio_id=p.id AND b.recruiter_id=?) as is_bookmarked
    FROM portfolios p
    JOIN users u ON p.student_id = u.id
    LEFT JOIN student_profiles sp ON u.id = sp.student_id
    WHERE $whereClause ORDER BY $order LIMIT 50");
$stmt->execute(array_merge([$user['id']], $params));
$portfolioList = $stmt->fetchAll();

// ── Bookmarked portfolios ─────────────────────────────────
$bookmarkStmt = $db->prepare("
    SELECT p.*, u.name as student_name, b.note, b.saved_at
    FROM bookmarks b
    JOIN portfolios p ON b.portfolio_id = p.id
    JOIN users u ON p.student_id = u.id
    WHERE b.recruiter_id = ? ORDER BY b.saved_at DESC");
$bookmarkStmt->execute([$user['id']]);
$bookmarkedList = $bookmarkStmt->fetchAll();

$pageTitles = ['home'=>'Dashboard','browse'=>'Browse Portfolios','bookmarks'=>'Bookmarks','notifications'=>'Notifications'];
dashboardOpen($pageTitles[$tab] ?? 'Dashboard', $user);

if ($flash) {
    [$ft,$fm] = str_starts_with($flash,'error:') ? ['danger',substr($flash,6)] : ['success',str_replace('success:','',$flash)];
    echo "<script>document.addEventListener('DOMContentLoaded',()=>toast(".json_encode($fm).",".json_encode($ft)."))</script>";
}
?>

<!-- ── HOME ──────────────────────────────────────────────── -->
<?php if ($tab === 'home'): ?>
<div class="stats-grid">
  <div class="stat-card" style="--card-color:#10B981">
    <div class="stat-icon">🗂️</div>
    <div class="stat-label">Active Portfolios</div>
    <div class="stat-value" data-count="<?= $totalPortfolios ?>"><?= $totalPortfolios ?></div>
    <div class="stat-change">Available to browse</div>
  </div>
  <div class="stat-card" style="--card-color:#6C63FF">
    <div class="stat-icon">🎓</div>
    <div class="stat-label">Students</div>
    <div class="stat-value" data-count="<?= $totalStudents ?>"><?= $totalStudents ?></div>
    <div class="stat-change">Registered on platform</div>
  </div>
  <div class="stat-card" style="--card-color:#F59E0B">
    <div class="stat-icon">🔖</div>
    <div class="stat-label">My Bookmarks</div>
    <div class="stat-value" data-count="<?= $myBookmarks ?>"><?= $myBookmarks ?></div>
    <div class="stat-change">Saved portfolios</div>
  </div>
</div>

<div class="section">
  <div class="section-head">
    <span class="section-title">🔥 Recently Added Portfolios</span>
    <a href="?tab=browse" class="btn btn-primary btn-sm">Browse All →</a>
  </div>
  <div class="section-body" style="padding:0">
    <?php
    $recent = $db->query("SELECT p.*,u.name as student_name,sp.college FROM portfolios p JOIN users u ON p.student_id=u.id LEFT JOIN student_profiles sp ON u.id=sp.student_id WHERE p.status='active' ORDER BY p.uploaded_at DESC LIMIT 5")->fetchAll();
    foreach ($recent as $p): ?>
    <div style="display:flex;align-items:center;gap:14px;padding:.9rem 1.4rem;border-bottom:1px solid var(--border)">
      <div style="width:36px;height:36px;background:linear-gradient(135deg,#6C63FF,#8B5CF6);border-radius:8px;display:flex;align-items:center;justify-content:center;font-family:'Syne',sans-serif;font-weight:700;font-size:.85rem;color:#fff;flex-shrink:0">
        <?= strtoupper(substr($p['student_name'],0,1)) ?>
      </div>
      <div style="flex:1;min-width:0">
        <div style="font-size:.875rem;font-weight:500"><?= htmlspecialchars($p['title']) ?></div>
        <div style="font-size:.75rem;color:var(--muted)"><?= htmlspecialchars($p['student_name']) ?><?= $p['college']?' · '.htmlspecialchars($p['college']):'' ?></div>
      </div>
      <div style="display:flex;gap:8px;flex-shrink:0">
        <a href="<?= htmlspecialchars($p['public_url']) ?>" target="_blank" class="btn btn-ghost btn-sm">View</a>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if (empty($recent)): ?>
      <div style="padding:2rem;text-align:center;color:var(--muted)">No portfolios available yet.</div>
    <?php endif; ?>
  </div>
</div>

<!-- ── BROWSE ─────────────────────────────────────────────── -->
<?php elseif ($tab === 'browse'): ?>
<form method="GET" action="">
  <input type="hidden" name="tab" value="browse">
  <div class="filter-row" style="margin-bottom:1.25rem">
    <div class="search-bar" style="flex:1;max-width:320px">
      <svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
      <input type="text" name="search" placeholder="Search by name, title, skill..." value="<?= htmlspecialchars($search) ?>">
    </div>
    <input type="text" class="form-input" name="skill" placeholder="Filter by skill (e.g. React)" style="width:180px" value="<?= htmlspecialchars($skillFil) ?>">
    <select class="form-select" name="sort" style="width:150px">
      <option value="newest" <?= $sortBy==='newest'?'selected':'' ?>>Newest First</option>
      <option value="views"  <?= $sortBy==='views' ?'selected':'' ?>>Most Viewed</option>
      <option value="name"   <?= $sortBy==='name'  ?'selected':'' ?>>Student Name</option>
    </select>
    <button type="submit" class="btn btn-primary btn-sm">🔍 Filter</button>
    <?php if ($search||$skillFil): ?><a href="?tab=browse" class="btn btn-ghost btn-sm">✕ Clear</a><?php endif; ?>
  </div>
</form>

<div style="font-size:.82rem;color:var(--muted);margin-bottom:1rem"><?= count($portfolioList) ?> portfolio<?= count($portfolioList)!=1?'s':'' ?> found</div>

<?php if (empty($portfolioList)): ?>
  <div class="section"><div class="section-body" style="text-align:center;padding:3rem;color:var(--muted)">
    <div style="font-size:2.5rem;margin-bottom:.75rem">🔍</div>
    <div>No portfolios found matching your search.</div>
  </div></div>
<?php else: ?>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:14px">
  <?php foreach ($portfolioList as $p): ?>
  <div class="section" style="margin-bottom:0">
    <div class="section-body">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:.75rem">
        <div style="display:flex;align-items:center;gap:10px">
          <div style="width:38px;height:38px;background:linear-gradient(135deg,#10B981,#059669);border-radius:10px;display:flex;align-items:center;justify-content:center;font-family:'Syne',sans-serif;font-weight:700;color:#fff;flex-shrink:0">
            <?= strtoupper(substr($p['student_name'],0,1)) ?>
          </div>
          <div>
            <div style="font-weight:500;font-size:.9rem"><?= htmlspecialchars($p['student_name']) ?></div>
            <?php if ($p['college']): ?><div style="font-size:.75rem;color:var(--muted)"><?= htmlspecialchars($p['college']) ?></div><?php endif; ?>
          </div>
        </div>
        <form method="POST" style="flex-shrink:0">
          <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
          <input type="hidden" name="action" value="toggle_bookmark">
          <input type="hidden" name="portfolio_id" value="<?= $p['id'] ?>">
          <button type="submit" class="btn btn-ghost btn-sm" title="<?= $p['is_bookmarked']?'Remove bookmark':'Save bookmark' ?>">
            <?= $p['is_bookmarked'] ? '🔖' : '🏷️' ?>
          </button>
        </form>
      </div>

      <div style="font-family:'Syne',sans-serif;font-weight:600;margin-bottom:.35rem"><?= htmlspecialchars($p['title']) ?></div>
      <?php if ($p['bio']): ?>
        <div style="font-size:.8rem;color:var(--muted);margin-bottom:.6rem;line-height:1.5;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden"><?= htmlspecialchars($p['bio']) ?></div>
      <?php endif; ?>

      <?php if ($p['skills']): ?>
        <div style="margin-bottom:.75rem;display:flex;flex-wrap:wrap;gap:5px">
          <?php foreach (array_slice(explode(',', $p['skills']), 0, 4) as $skill): ?>
            <span style="font-size:.7rem;padding:2px 8px;background:rgba(108,99,255,0.12);color:#A78BFA;border-radius:20px;border:1px solid rgba(108,99,255,0.2)"><?= htmlspecialchars(trim($skill)) ?></span>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

      <div style="display:flex;align-items:center;justify-content:space-between">
        <span style="font-size:.75rem;color:var(--muted)">👁️ <?= $p['views'] ?> views · <?= timeAgo($p['uploaded_at']) ?></span>
        <a href="<?= htmlspecialchars($p['public_url']) ?>" target="_blank" class="btn btn-success btn-sm">View Portfolio →</a>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- ── BOOKMARKS ──────────────────────────────────────────── -->
<?php elseif ($tab === 'bookmarks'): ?>
<?php if (empty($bookmarkedList)): ?>
  <div class="section"><div class="section-body" style="text-align:center;padding:3rem;color:var(--muted)">
    <div style="font-size:2.5rem;margin-bottom:.75rem">🔖</div>
    <div>No bookmarks yet.</div>
    <a href="?tab=browse" class="btn btn-primary" style="margin-top:.75rem">Browse Portfolios</a>
  </div></div>
<?php else: ?>
  <div style="display:grid;gap:12px">
    <?php foreach ($bookmarkedList as $b): ?>
    <div class="section">
      <div class="section-body" style="display:flex;align-items:center;gap:14px;flex-wrap:wrap">
        <div style="flex:1;min-width:0">
          <div style="font-family:'Syne',sans-serif;font-weight:700;margin-bottom:2px"><?= htmlspecialchars($b['title']) ?></div>
          <div style="font-size:.82rem;color:var(--muted)">by <?= htmlspecialchars($b['student_name']) ?> · saved <?= timeAgo($b['saved_at']) ?></div>
          <?php if ($b['note']): ?><div style="font-size:.8rem;color:var(--muted);margin-top:4px;font-style:italic">"<?= htmlspecialchars($b['note']) ?>"</div><?php endif; ?>
        </div>
        <div style="display:flex;gap:8px">
          <a href="<?= htmlspecialchars($b['public_url']) ?>" target="_blank" class="btn btn-success btn-sm">View</a>
          <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
            <input type="hidden" name="action" value="toggle_bookmark">
            <input type="hidden" name="portfolio_id" value="<?= $b['id'] ?>">
            <button type="submit" class="btn btn-danger btn-sm">Remove</button>
          </form>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-count]').forEach(el => {
    const t = parseInt(el.dataset.count), step = Math.ceil(t/25);
    let c = 0; const iv = setInterval(() => { c=Math.min(c+step,t); el.textContent=c; if(c>=t)clearInterval(iv); }, 50);
  });
});
</script>
<?php dashboardClose(); ?>
