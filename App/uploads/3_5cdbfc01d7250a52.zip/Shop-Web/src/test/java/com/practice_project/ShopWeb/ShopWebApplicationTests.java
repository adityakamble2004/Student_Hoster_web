package com.practice_project.ShopWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
