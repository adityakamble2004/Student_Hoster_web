<?php
// includes/dashboard_layout.php
// Usage: require this AFTER setting $pageTitle and $activeNav and $user
// Then call dashboard_content_start() → your content → dashboard_content_end()

function renderSidebar(array $user): void {
    $role     = $user['role'];
    $initials = strtoupper(substr($user['name'], 0, 1) . (strpos($user['name'],' ')!==false ? substr($user['name'], strpos($user['name'],' ')+1, 1) : ''));
    $unread   = unreadNotifications($user['id']);

    $navItems = [
        'student' => [
            ['icon'=>'📊','label'=>'Dashboard','href'=>'/dashboard/student.php','key'=>'home'],
            ['icon'=>'⬆️','label'=>'Upload Portfolio','href'=>'/dashboard/student.php?tab=upload','key'=>'upload'],
            ['icon'=>'🗂️','label'=>'My Portfolios','href'=>'/dashboard/student.php?tab=portfolios','key'=>'portfolios'],
            ['icon'=>'👤','label'=>'My Profile','href'=>'/dashboard/student.php?tab=profile','key'=>'profile'],
            ['icon'=>'🔔','label'=>'Notifications','href'=>'/dashboard/student.php?tab=notifications','key'=>'notifications'],
        ],
        'recruiter' => [
            ['icon'=>'📊','label'=>'Dashboard','href'=>'/dashboard/recruiter.php','key'=>'home'],
            ['icon'=>'🔍','label'=>'Browse Portfolios','href'=>'/dashboard/recruiter.php?tab=browse','key'=>'browse'],
            ['icon'=>'🔖','label'=>'Bookmarks','href'=>'/dashboard/recruiter.php?tab=bookmarks','key'=>'bookmarks'],
            ['icon'=>'🔔','label'=>'Notifications','href'=>'/dashboard/recruiter.php?tab=notifications','key'=>'notifications'],
        ],
        'moderator' => [
            ['icon'=>'📊','label'=>'Dashboard','href'=>'/dashboard/moderator.php','key'=>'home'],
            ['icon'=>'⏳','label'=>'Pending Approvals','href'=>'/dashboard/moderator.php?tab=pending','key'=>'pending'],
            ['icon'=>'👥','label'=>'Students','href'=>'/dashboard/moderator.php?tab=students','key'=>'students'],
            ['icon'=>'📋','label'=>'Activity Logs','href'=>'/dashboard/moderator.php?tab=logs','key'=>'logs'],
        ],
        'admin' => [
            ['icon'=>'📊','label'=>'Dashboard','href'=>'/dashboard/admin.php','key'=>'home'],
            ['icon'=>'👥','label'=>'All Users','href'=>'/dashboard/admin.php?tab=users','key'=>'users'],
            ['icon'=>'🗂️','label'=>'Portfolios','href'=>'/dashboard/admin.php?tab=portfolios','key'=>'portfolios'],
            ['icon'=>'💾','label'=>'Storage','href'=>'/dashboard/admin.php?tab=storage','key'=>'storage'],
            ['icon'=>'📋','label'=>'Activity Logs','href'=>'/dashboard/admin.php?tab=logs','key'=>'logs'],
            ['icon'=>'⚙️','label'=>'Settings','href'=>'/dashboard/admin.php?tab=settings','key'=>'settings'],
        ],
    ];

    $items = $navItems[$role] ?? [];
    $activeKey = $_GET['tab'] ?? 'home';

    $roleColors = [
        'student'   => ['#6C63FF','#8B5CF6'],
        'recruiter' => ['#10B981','#059669'],
        'moderator' => ['#F59E0B','#D97706'],
        'admin'     => ['#EF4444','#DC2626'],
    ];
    [$c1,$c2] = $roleColors[$role];
    ?>
    <aside class="sidebar" id="sidebar">
      <div class="sidebar-top">
        <div class="brand">
          <div class="brand-icon">🎯</div>
          <span class="brand-name">PortfolioHost</span>
        </div>
        <button class="sidebar-close" onclick="toggleSidebar()">✕</button>
      </div>

      <nav class="nav">
        <?php foreach ($items as $item): ?>
        <a href="<?= APP_URL . $item['href'] ?>"
           class="nav-item <?= ($activeKey === $item['key'] || ($activeKey==='home' && $item['key']==='home')) ? 'active' : '' ?>">
          <span class="nav-icon"><?= $item['icon'] ?></span>
          <span class="nav-label"><?= $item['label'] ?></span>
          <?php if ($item['key']==='notifications' && $unread > 0): ?>
            <span class="nav-badge"><?= $unread ?></span>
          <?php endif; ?>
        </a>
        <?php endforeach; ?>
      </nav>

      <div class="sidebar-footer">
        <div class="user-card">
          <div class="avatar" style="background:linear-gradient(135deg,<?= $c1 ?>,<?= $c2 ?>)"><?= $initials ?></div>
          <div class="user-info">
            <div class="user-name"><?= htmlspecialchars($user['name']) ?></div>
            <div class="user-role"><?= ucfirst($role) ?></div>
          </div>
          <a href="<?= APP_URL ?>/auth/logout.php" class="logout-btn" title="Sign out">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
              <polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>
            </svg>
          </a>
        </div>
      </div>
    </aside>
    <?php
}

function dashboardHead(string $title): void {
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($title) ?> — PortfolioHost</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
<style>
/* ── Reset & Variables ───────────────────────────────────── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
:root {
  --bg:       #080B14;
  --surface:  #0F1422;
  --surface2: #141827;
  --border:   rgba(255,255,255,0.07);
  --border2:  rgba(255,255,255,0.12);
  --primary:  #6C63FF;
  --primary2: #8B5CF6;
  --text:     #E8E8F0;
  --muted:    #6B6F80;
  --success:  #10B981;
  --warning:  #F59E0B;
  --danger:   #EF4444;
  --info:     #3B82F6;
  --sidebar-w: 240px;
}

body {
  font-family: 'DM Sans', sans-serif;
  background: var(--bg);
  color: var(--text);
  min-height: 100vh;
  display: flex;
}

/* ── Sidebar ─────────────────────────────────────────────── */
.sidebar {
  width: var(--sidebar-w);
  min-height: 100vh;
  background: var(--surface);
  border-right: 1px solid var(--border);
  display: flex;
  flex-direction: column;
  position: fixed;
  top: 0; left: 0; bottom: 0;
  z-index: 100;
  transition: transform 0.3s cubic-bezier(0.16,1,0.3,1);
}
.sidebar-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1.5rem 1.25rem 1rem;
  border-bottom: 1px solid var(--border);
}
.brand { display: flex; align-items: center; gap: 10px; }
.brand-icon { font-size: 1.3rem; }
.brand-name { font-family: 'Syne', sans-serif; font-weight: 700; font-size: 1rem; letter-spacing: -0.02em; }
.sidebar-close { display: none; background: none; border: none; color: var(--muted); cursor: pointer; font-size: 1rem; padding: 4px; }

.nav { flex: 1; padding: 1rem 0.75rem; display: flex; flex-direction: column; gap: 2px; }
.nav-item {
  display: flex; align-items: center; gap: 10px;
  padding: 0.65rem 0.9rem; border-radius: 10px;
  color: var(--muted); text-decoration: none;
  font-size: 0.88rem; font-weight: 400;
  transition: all 0.15s;
  position: relative;
}
.nav-item:hover { background: rgba(255,255,255,0.05); color: var(--text); }
.nav-item.active { background: rgba(108,99,255,0.15); color: var(--text); font-weight: 500; }
.nav-item.active::before {
  content: ''; position: absolute; left: 0; top: 50%; transform: translateY(-50%);
  width: 3px; height: 60%; background: var(--primary); border-radius: 0 3px 3px 0;
}
.nav-icon { font-size: 1rem; width: 20px; text-align: center; }
.nav-label { flex: 1; }
.nav-badge {
  background: var(--danger); color: #fff; font-size: 0.7rem; font-weight: 600;
  padding: 1px 6px; border-radius: 20px; min-width: 18px; text-align: center;
}

.sidebar-footer { padding: 1rem 0.75rem; border-top: 1px solid var(--border); }
.user-card { display: flex; align-items: center; gap: 10px; }
.avatar {
  width: 36px; height: 36px; border-radius: 10px;
  display: flex; align-items: center; justify-content: center;
  font-family: 'Syne', sans-serif; font-weight: 700; font-size: 0.85rem; color: #fff;
  flex-shrink: 0;
}
.user-info { flex: 1; min-width: 0; }
.user-name { font-size: 0.85rem; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.user-role { font-size: 0.72rem; color: var(--muted); text-transform: capitalize; }
.logout-btn { color: var(--muted); padding: 6px; border-radius: 8px; transition: all 0.15s; }
.logout-btn:hover { background: rgba(239,68,68,0.15); color: var(--danger); }

/* ── Main Content ────────────────────────────────────────── */
.main {
  margin-left: var(--sidebar-w);
  flex: 1;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.topbar {
  background: var(--surface);
  border-bottom: 1px solid var(--border);
  padding: 0.9rem 1.75rem;
  display: flex;
  align-items: center;
  gap: 16px;
  position: sticky;
  top: 0;
  z-index: 50;
}
.menu-btn {
  display: none; background: none; border: none;
  color: var(--text); cursor: pointer; padding: 4px; font-size: 1.1rem;
}
.topbar-title { font-family: 'Syne', sans-serif; font-weight: 700; font-size: 1.1rem; letter-spacing: -0.02em; }
.topbar-right { margin-left: auto; display: flex; align-items: center; gap: 12px; }

.page { padding: 1.75rem; flex: 1; }

/* ── Stat Cards ──────────────────────────────────────────── */
.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 14px;
  margin-bottom: 1.75rem;
}
.stat-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 14px;
  padding: 1.25rem;
  position: relative;
  overflow: hidden;
  transition: border-color 0.2s, transform 0.2s;
  cursor: default;
}
.stat-card:hover { border-color: var(--border2); transform: translateY(-2px); }
.stat-card::after {
  content: '';
  position: absolute; top: 0; right: 0;
  width: 80px; height: 80px;
  background: radial-gradient(circle, var(--card-color, var(--primary)) 0%, transparent 70%);
  opacity: 0.08;
  transform: translate(20px,-20px);
}
.stat-label { font-size: 0.78rem; color: var(--muted); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 0.5rem; }
.stat-value { font-family: 'Syne', sans-serif; font-size: 1.9rem; font-weight: 800; letter-spacing: -0.03em; }
.stat-change { font-size: 0.78rem; color: var(--muted); margin-top: 0.3rem; }
.stat-icon { position: absolute; top: 1.1rem; right: 1.1rem; font-size: 1.3rem; opacity: 0.5; }

/* ── Content Sections ────────────────────────────────────── */
.section { background: var(--surface); border: 1px solid var(--border); border-radius: 14px; overflow: hidden; margin-bottom: 1.5rem; }
.section-head {
  display: flex; align-items: center; justify-content: space-between;
  padding: 1.1rem 1.4rem; border-bottom: 1px solid var(--border);
}
.section-title { font-family: 'Syne', sans-serif; font-weight: 700; font-size: 0.95rem; }
.section-body { padding: 1.4rem; }

/* ── Buttons ─────────────────────────────────────────────── */
.btn {
  display: inline-flex; align-items: center; gap: 7px;
  padding: 0.6rem 1.1rem; border-radius: 9px;
  font-family: 'DM Sans', sans-serif; font-size: 0.88rem; font-weight: 500;
  cursor: pointer; border: none; text-decoration: none; transition: all 0.15s;
  white-space: nowrap;
}
.btn-primary { background: var(--primary); color: #fff; }
.btn-primary:hover { background: var(--primary2); transform: translateY(-1px); }
.btn-ghost { background: rgba(255,255,255,0.05); color: var(--text); border: 1px solid var(--border); }
.btn-ghost:hover { background: rgba(255,255,255,0.09); border-color: var(--border2); }
.btn-success { background: rgba(16,185,129,0.15); color: var(--success); }
.btn-success:hover { background: rgba(16,185,129,0.25); }
.btn-danger { background: rgba(239,68,68,0.15); color: var(--danger); }
.btn-danger:hover { background: rgba(239,68,68,0.25); }
.btn-sm { padding: 0.4rem 0.75rem; font-size: 0.8rem; }

/* ── Badges ──────────────────────────────────────────────── */
.badge {
  display: inline-flex; align-items: center; gap: 4px;
  padding: 3px 9px; border-radius: 20px; font-size: 0.72rem; font-weight: 500;
}
.badge-success  { background: rgba(16,185,129,0.15); color: #34D399; }
.badge-warning  { background: rgba(245,158,11,0.15); color: #FCD34D; }
.badge-danger   { background: rgba(239,68,68,0.15);  color: #FCA5A5; }
.badge-info     { background: rgba(59,130,246,0.15);  color: #93C5FD; }
.badge-gray     { background: rgba(255,255,255,0.07); color: var(--muted); }

/* ── Table ───────────────────────────────────────────────── */
.table-wrap { overflow-x: auto; }
table { width: 100%; border-collapse: collapse; font-size: 0.875rem; }
th {
  padding: 0.75rem 1rem; text-align: left; font-size: 0.75rem; font-weight: 500;
  color: var(--muted); text-transform: uppercase; letter-spacing: 0.05em;
  border-bottom: 1px solid var(--border); white-space: nowrap;
}
td { padding: 0.85rem 1rem; border-bottom: 1px solid var(--border); vertical-align: middle; }
tr:last-child td { border-bottom: none; }
tr:hover td { background: rgba(255,255,255,0.02); }

/* ── Search Input ────────────────────────────────────────── */
.search-bar {
  display: flex; align-items: center; gap: 8px;
  background: rgba(255,255,255,0.04); border: 1px solid var(--border);
  border-radius: 10px; padding: 0.6rem 0.9rem; min-width: 220px;
}
.search-bar input {
  background: none; border: none; outline: none; color: var(--text);
  font-family: 'DM Sans', sans-serif; font-size: 0.875rem; width: 100%;
}
.search-bar svg { color: var(--muted); flex-shrink: 0; }
.filter-row { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }

/* ── Progress Bar ────────────────────────────────────────── */
.progress-bar { background: rgba(255,255,255,0.08); border-radius: 20px; height: 8px; overflow: hidden; }
.progress-fill { height: 100%; border-radius: 20px; transition: width 0.8s cubic-bezier(0.16,1,0.3,1); }

/* ── Form Elements ───────────────────────────────────────── */
.form-group { margin-bottom: 1rem; }
.form-label { display: block; font-size: 0.82rem; color: var(--muted); margin-bottom: 0.4rem; font-weight: 500; text-transform: uppercase; letter-spacing: 0.03em; }
.form-input, .form-select, .form-textarea {
  width: 100%; background: rgba(255,255,255,0.04); border: 1px solid var(--border);
  border-radius: 9px; padding: 0.7rem 0.9rem; color: var(--text);
  font-family: 'DM Sans', sans-serif; font-size: 0.9rem; outline: none;
  transition: border-color 0.2s;
}
.form-input:focus, .form-select:focus, .form-textarea:focus {
  border-color: var(--primary); box-shadow: 0 0 0 3px rgba(108,99,255,0.12);
}
.form-select option { background: var(--surface2); }
.form-textarea { resize: vertical; min-height: 90px; }

/* ── Upload Drop Zone ────────────────────────────────────── */
.drop-zone {
  border: 2px dashed var(--border2); border-radius: 14px; padding: 2.5rem;
  text-align: center; cursor: pointer; transition: all 0.2s;
}
.drop-zone:hover, .drop-zone.dragover {
  border-color: var(--primary); background: rgba(108,99,255,0.05);
}
.drop-zone-icon { font-size: 2.5rem; margin-bottom: 0.75rem; }
.drop-zone-title { font-family: 'Syne', sans-serif; font-weight: 600; margin-bottom: 0.35rem; }
.drop-zone-sub { font-size: 0.875rem; color: var(--muted); }

/* ── Toast Notifications ─────────────────────────────────── */
.toast-container { position: fixed; bottom: 1.5rem; right: 1.5rem; z-index: 9999; display: flex; flex-direction: column; gap: 8px; }
.toast {
  background: var(--surface2); border: 1px solid var(--border2);
  border-radius: 12px; padding: 0.9rem 1.2rem;
  display: flex; align-items: center; gap: 12px;
  font-size: 0.875rem; max-width: 320px; box-shadow: 0 8px 32px rgba(0,0,0,0.4);
  animation: toastIn 0.3s cubic-bezier(0.16,1,0.3,1) both;
}
@keyframes toastIn { from{opacity:0;transform:translateX(50px)} to{opacity:1;transform:translateX(0)} }
.toast.success .toast-dot { background: var(--success); }
.toast.danger  .toast-dot { background: var(--danger); }
.toast.warning .toast-dot { background: var(--warning); }
.toast-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }

/* ── Modal ───────────────────────────────────────────────── */
.modal-overlay {
  position: fixed; inset: 0; background: rgba(0,0,0,0.7); backdrop-filter: blur(4px);
  z-index: 200; display: flex; align-items: center; justify-content: center; padding: 1rem;
  opacity: 0; pointer-events: none; transition: opacity 0.2s;
}
.modal-overlay.open { opacity: 1; pointer-events: all; }
.modal {
  background: var(--surface); border: 1px solid var(--border2);
  border-radius: 16px; padding: 1.75rem; width: 100%; max-width: 480px;
  transform: scale(0.95); transition: transform 0.25s cubic-bezier(0.16,1,0.3,1);
}
.modal-overlay.open .modal { transform: scale(1); }
.modal-title { font-family: 'Syne', sans-serif; font-weight: 700; font-size: 1.1rem; margin-bottom: 1rem; }
.modal-footer { display: flex; gap: 10px; justify-content: flex-end; margin-top: 1.5rem; }

/* ── Two-column Grid ─────────────────────────────────────── */
.grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 1.25rem; }
.grid-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1.25rem; }

/* ── Responsive ──────────────────────────────────────────── */
@media (max-width: 768px) {
  .sidebar { transform: translateX(-100%); }
  .sidebar.open { transform: translateX(0); box-shadow: 4px 0 20px rgba(0,0,0,0.5); }
  .sidebar-close { display: block; }
  .main { margin-left: 0; }
  .menu-btn { display: block; }
  .stats-grid { grid-template-columns: 1fr 1fr; }
  .grid-2, .grid-3 { grid-template-columns: 1fr; }
  .page { padding: 1rem; }
}
@media (max-width: 480px) {
  .stats-grid { grid-template-columns: 1fr; }
}

/* Overlay for mobile sidebar */
.sidebar-overlay {
  display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.6); z-index: 99;
}
.sidebar-overlay.show { display: block; }
</style>
<?php
}

function dashboardOpen(string $title, array $user): void {
    dashboardHead($title);
    echo '</head><body>';
    echo '<div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>';
    renderSidebar($user);
    echo '<div class="main">';
    echo '<div class="topbar">';
    echo '<button class="menu-btn" onclick="toggleSidebar()">☰</button>';
    echo '<span class="topbar-title">' . htmlspecialchars($title) . '</span>';
    echo '<div class="topbar-right">';
    $unread = unreadNotifications($user['id']);
    if ($unread > 0) echo "<span style='font-size:.8rem;color:var(--warning)'>🔔 $unread</span>";
    echo '<span style="font-size:.85rem;color:var(--muted)">' . htmlspecialchars($user['name']) . '</span>';
    echo '</div>';
    echo '</div>';
    echo '<div class="page">';
}

function dashboardClose(): void {
    echo '</div></div>';
    echo '<div class="toast-container" id="toastContainer"></div>';
    ?>
<script>
function toggleSidebar() {
  const sb = document.getElementById('sidebar');
  const ov = document.getElementById('sidebarOverlay');
  sb.classList.toggle('open');
  ov.classList.toggle('show');
}
function toast(msg, type='success') {
  const tc = document.getElementById('toastContainer');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<div class="toast-dot"></div><span>${msg}</span>`;
  tc.appendChild(el);
  setTimeout(() => el.remove(), 3500);
}
function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') document.querySelectorAll('.modal-overlay.open').forEach(m => m.classList.remove('open'));
});
</script>
</body></html>
<?php
}
