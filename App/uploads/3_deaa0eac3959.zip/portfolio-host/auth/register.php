<?php
require_once __DIR__ . '/../includes/auth_helper.php';

if (isLoggedIn()) {
    header('Location: ' . APP_URL . ROLE_DASHBOARDS[$_SESSION['role']]); exit;
}

$error = $success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm'] ?? '';
    $role     = $_POST['role'] ?? 'student';

    if (!$name || !$email || !$password || !$confirm) {
        $error = 'Please fill in all fields.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        $result = registerUser($name, $email, $password, $role);
        if ($result['success']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Create Account — PortfolioHost</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --bg: #080B14; --surface: #0F1422; --border: rgba(255,255,255,0.07);
    --primary: #6C63FF; --primary2: #8B5CF6; --text: #E8E8F0; --muted: #6B6F80;
    --success: #10B981; --danger: #EF4444;
  }
  body {
    font-family: 'DM Sans', sans-serif; background: var(--bg); color: var(--text);
    min-height: 100vh; display: flex; align-items: center; justify-content: center;
    padding: 1.5rem; position: relative; overflow: hidden;
  }
  body::before, body::after {
    content: ''; position: fixed; border-radius: 50%;
    filter: blur(80px); opacity: 0.18; animation: float 8s ease-in-out infinite; pointer-events: none;
  }
  body::before { width: 500px; height: 500px; background: #6C63FF; top: -150px; right: -100px; }
  body::after  { width: 350px; height: 350px; background: #10B981; bottom: -80px; left: -80px; animation-delay: -4s; }
  @keyframes float { 0%,100%{transform:translate(0,0)} 50%{transform:translate(20px,15px)} }

  .card {
    background: var(--surface); border: 1px solid var(--border); border-radius: 20px;
    width: 100%; max-width: 460px; padding: 2.5rem; position: relative; z-index: 1;
    animation: slideUp 0.5s cubic-bezier(0.16,1,0.3,1) both;
  }
  @keyframes slideUp { from{opacity:0;transform:translateY(30px)} to{opacity:1;transform:translateY(0)} }

  .logo { display:flex; align-items:center; gap:10px; margin-bottom:1.8rem; }
  .logo-icon { width:40px; height:40px; background:linear-gradient(135deg,var(--primary),var(--primary2)); border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:18px; }
  .logo-text { font-family:'Syne',sans-serif; font-weight:700; font-size:1.15rem; letter-spacing:-0.02em; }
  .heading { font-family:'Syne',sans-serif; font-size:1.7rem; font-weight:800; letter-spacing:-0.03em; margin-bottom:0.4rem; }
  .sub { color:var(--muted); font-size:0.9rem; margin-bottom:1.8rem; }

  .field { margin-bottom:1.1rem; }
  label { display:block; font-size:0.82rem; font-weight:500; color:var(--muted); margin-bottom:0.45rem; letter-spacing:0.03em; text-transform:uppercase; }
  input[type=text], input[type=email], input[type=password] {
    width:100%; background:rgba(255,255,255,0.04); border:1px solid var(--border);
    border-radius:10px; padding:0.82rem 1rem; color:var(--text);
    font-family:'DM Sans',sans-serif; font-size:0.95rem; outline:none;
    transition:border-color 0.2s, box-shadow 0.2s;
  }
  input:focus { border-color:var(--primary); box-shadow:0 0 0 3px rgba(108,99,255,0.15); }

  /* Role selector */
  .role-grid { display:grid; grid-template-columns:1fr 1fr; gap:8px; }
  .role-option { display:none; }
  .role-label {
    display:flex; flex-direction:column; align-items:center; gap:6px;
    padding:1rem; background:rgba(255,255,255,0.04); border:2px solid var(--border);
    border-radius:12px; cursor:pointer; transition:all 0.2s; text-align:center;
  }
  .role-option:checked + .role-label {
    border-color:var(--primary); background:rgba(108,99,255,0.12);
  }
  .role-label .role-icon { font-size:1.5rem; }
  .role-label .role-name { font-family:'Syne',sans-serif; font-size:0.85rem; font-weight:600; }
  .role-label .role-desc { font-size:0.72rem; color:var(--muted); }

  .btn {
    width:100%; padding:0.9rem; background:linear-gradient(135deg,var(--primary),var(--primary2));
    color:#fff; border:none; border-radius:10px; font-family:'Syne',sans-serif;
    font-size:1rem; font-weight:600; cursor:pointer; margin-top:0.5rem; letter-spacing:0.01em;
    transition:opacity 0.2s, transform 0.15s;
  }
  .btn:hover { opacity:0.9; transform:translateY(-1px); }

  .alert {
    border-radius:10px; padding:0.75rem 1rem; font-size:0.875rem; margin-bottom:1.2rem;
    display:flex; align-items:center; gap:8px;
  }
  .alert.error  { background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.3); color:#FCA5A5; }
  .alert.success{ background:rgba(16,185,129,0.1); border:1px solid rgba(16,185,129,0.3); color:#6EE7B7; }

  .link-row { text-align:center; color:var(--muted); font-size:0.875rem; margin-top:1.4rem; }
  .link-row a { color:var(--primary); text-decoration:none; font-weight:500; }
  .pass-wrap { position:relative; }
  .pass-wrap input { padding-right:2.8rem; }
  .pass-toggle { position:absolute; right:12px; top:50%; transform:translateY(-50%); background:none; border:none; cursor:pointer; color:var(--muted); padding:4px; }
  .pass-toggle:hover { color:var(--text); }
</style>
</head>
<body>
<div class="card">
  <div class="logo">
    <div class="logo-icon">🎯</div>
    <span class="logo-text">PortfolioHost</span>
  </div>

  <h1 class="heading">Create account</h1>
  <p class="sub">Join and get your own hosted space</p>

  <?php if ($error): ?>
  <div class="alert error">
    <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
    <?= htmlspecialchars($error) ?>
  </div>
  <?php elseif ($success): ?>
  <div class="alert success">
    <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
    <?= htmlspecialchars($success) ?> <a href="login.php" style="color:inherit;text-decoration:underline;margin-left:6px">Sign in →</a>
  </div>
  <?php endif; ?>

  <form method="POST">
    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">

    <div class="field">
      <label>I am a</label>
      <div class="role-grid">
        <div>
          <input type="radio" name="role" id="r-student" value="student" class="role-option"
                 <?= ($_POST['role']??'student')==='student'?'checked':'' ?>>
          <label for="r-student" class="role-label">
            <span class="role-icon">🎓</span>
            <span class="role-name">Student</span>
            <span class="role-desc">Host my portfolio</span>
          </label>
        </div>
        <div>
          <input type="radio" name="role" id="r-recruiter" value="recruiter" class="role-option"
                 <?= ($_POST['role']??'')==='recruiter'?'checked':'' ?>>
          <label for="r-recruiter" class="role-label">
            <span class="role-icon">💼</span>
            <span class="role-name">Recruiter</span>
            <span class="role-desc">Browse talent</span>
          </label>
        </div>
      </div>
    </div>

    <div class="field">
      <label for="name">Full Name</label>
      <input type="text" id="name" name="name" placeholder="Aditya Kamble"
             value="<?= htmlspecialchars($_POST['name']??'') ?>" required>
    </div>

    <div class="field">
      <label for="email">Email Address</label>
      <input type="email" id="email" name="email" placeholder="you@example.com"
             value="<?= htmlspecialchars($_POST['email']??'') ?>" required>
    </div>

    <div class="field">
      <label for="password">Password <span style="color:var(--muted);font-size:0.75rem;text-transform:none">(min. 8 chars)</span></label>
      <div class="pass-wrap">
        <input type="password" id="password" name="password" placeholder="Create a strong password" required>
        <button type="button" class="pass-toggle" onclick="document.getElementById('password').type=document.getElementById('password').type==='password'?'text':'password'">👁</button>
      </div>
    </div>

    <div class="field">
      <label for="confirm">Confirm Password</label>
      <input type="password" id="confirm" name="confirm" placeholder="Repeat your password" required>
    </div>

    <button type="submit" class="btn">Create My Account →</button>
  </form>

  <p class="link-row">Already have an account? <a href="login.php">Sign in</a></p>
</div>
</body>
</html>
