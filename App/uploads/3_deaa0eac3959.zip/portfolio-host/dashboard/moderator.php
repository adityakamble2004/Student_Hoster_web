<?php
require_once __DIR__ . '/../includes/auth_helper.php';
require_once __DIR__ . '/../includes/dashboard_layout.php';
requireRole(['moderator','admin']);
$user = currentUser();
$db   = getDB();
$tab  = $_GET['tab'] ?? 'home';

// ── Stats ─────────────────────────────────────────────────
$pending  = $db->query("SELECT COUNT(*) FROM portfolios WHERE status='pending'")->fetchColumn();
$approved = $db->query("SELECT COUNT(*) FROM portfolios WHERE status='active'")->fetchColumn();
$rejected = $db->query("SELECT COUNT(*) FROM portfolios WHERE status='rejected'")->fetchColumn();
$students = $db->query("SELECT COUNT(*) FROM users WHERE role='student'")->fetchColumn();

// ── Handle POST ───────────────────────────────────────────
$flash = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'approve_portfolio') {
        $pid = (int)$_POST['portfolio_id'];
        $db->prepare("UPDATE portfolios SET status='active' WHERE id=?")->execute([$pid]);
        // Notify student
        $port = $db->query("SELECT p.title,p.student_id FROM portfolios p WHERE p.id=$pid")->fetch();
        if ($port) sendNotification($port['student_id'], '✅ Portfolio Approved', "Your portfolio \"{$port['title']}\" has been approved and is now live!", 'success');
        logActivity($user['id'],'approve_portfolio',"Approved portfolio ID $pid");
        $flash = 'success:Portfolio approved and is now live!';
    }

    if ($action === 'reject_portfolio') {
        $pid    = (int)$_POST['portfolio_id'];
        $reason = trim($_POST['reason'] ?? 'Does not meet quality standards.');
        $db->prepare("UPDATE portfolios SET status='rejected', rejection_reason=? WHERE id=?")->execute([$reason,$pid]);
        $port = $db->query("SELECT p.title,p.student_id FROM portfolios p WHERE p.id=$pid")->fetch();
        if ($port) sendNotification($port['student_id'], '❌ Portfolio Rejected', "Your portfolio \"{$port['title']}\" was rejected. Reason: $reason", 'danger');
        logActivity($user['id'],'reject_portfolio',"Rejected portfolio ID $pid: $reason");
        $flash = 'success:Portfolio rejected.';
    }

    if ($action === 'suspend_student') {
        $sid = (int)$_POST['student_id'];
        $db->prepare("UPDATE users SET status='suspended' WHERE id=? AND role='student'")->execute([$sid]);
        logActivity($user['id'],'suspend_student',"Suspended student ID $sid");
        $flash = 'success:Student account suspended.';
    }

    if ($action === 'activate_student') {
        $sid = (int)$_POST['student_id'];
        $db->prepare("UPDATE users SET status='active' WHERE id=? AND role='student'")->execute([$sid]);
        logActivity($user['id'],'activate_student',"Activated student ID $sid");
        $flash = 'success:Student account activated.';
    }
}

// ── Pending portfolios ────────────────────────────────────
$pendingList = $db->query("
    SELECT p.*, u.name as student_name, u.email as student_email
    FROM portfolios p JOIN users u ON p.student_id=u.id
    WHERE p.status='pending' ORDER BY p.uploaded_at ASC")->fetchAll();

// ── Students list ─────────────────────────────────────────
$search    = trim($_GET['search'] ?? '');
$statusFil = $_GET['status'] ?? '';
$where = "u.role='student'";
$params = [];
if ($search)    { $where .= " AND (u.name LIKE ? OR u.email LIKE ?)"; $params[]="%$search%"; $params[]="%$search%"; }
if ($statusFil) { $where .= " AND u.status = ?"; $params[] = $statusFil; }
$studentsQuery = $db->prepare("
    SELECT u.*, su.used_mb, su.limit_mb,
           (SELECT COUNT(*) FROM portfolios p WHERE p.student_id=u.id AND p.status='active') as active_portfolios
    FROM users u LEFT JOIN storage_usage su ON u.id=su.student_id
    WHERE $where ORDER BY u.created_at DESC LIMIT 100");
$studentsQuery->execute($params);
$studentsList = $studentsQuery->fetchAll();

// ── Activity logs ─────────────────────────────────────────
$logs = $db->query("SELECT l.*, u.name as user_name FROM activity_logs l LEFT JOIN users u ON l.user_id=u.id ORDER BY l.created_at DESC LIMIT 80")->fetchAll();

$pageTitles = ['home'=>'Dashboard','pending'=>'Pending Approvals','students'=>'Manage Students','logs'=>'Activity Logs'];
dashboardOpen($pageTitles[$tab] ?? 'Dashboard', $user);

if ($flash) {
    [$ft,$fm] = str_starts_with($flash,'error:') ? ['danger',substr($flash,6)] : ['success',str_replace('success:','',$flash)];
    echo "<script>document.addEventListener('DOMContentLoaded',()=>toast(".json_encode($fm).",".json_encode($ft)."))</script>";
}
?>

<!-- ── HOME ──────────────────────────────────────────────── -->
<?php if ($tab === 'home'): ?>
<div class="stats-grid">
  <div class="stat-card" style="--card-color:#F59E0B">
    <div class="stat-icon">⏳</div>
    <div class="stat-label">Pending Review</div>
    <div class="stat-value" data-count="<?= $pending ?>"><?= $pending ?></div>
    <?php if ($pending > 0): ?><div style="margin-top:.5rem"><a href="?tab=pending" class="btn btn-warning btn-sm" style="background:rgba(245,158,11,.2);color:#FCD34D;border:none">Review Now →</a></div><?php endif; ?>
  </div>
  <div class="stat-card" style="--card-color:#10B981">
    <div class="stat-icon">✅</div>
    <div class="stat-label">Approved</div>
    <div class="stat-value" data-count="<?= $approved ?>"><?= $approved ?></div>
    <div class="stat-change">Live portfolios</div>
  </div>
  <div class="stat-card" style="--card-color:#EF4444">
    <div class="stat-icon">❌</div>
    <div class="stat-label">Rejected</div>
    <div class="stat-value" data-count="<?= $rejected ?>"><?= $rejected ?></div>
    <div class="stat-change">Did not meet standards</div>
  </div>
  <div class="stat-card" style="--card-color:#6C63FF">
    <div class="stat-icon">🎓</div>
    <div class="stat-label">Total Students</div>
    <div class="stat-value" data-count="<?= $students ?>"><?= $students ?></div>
    <div class="stat-change">Registered accounts</div>
  </div>
</div>

<?php if (!empty($pendingList)): ?>
<div class="section">
  <div class="section-head">
    <span class="section-title">🕐 Awaiting Your Review</span>
    <span class="badge badge-warning"><?= count($pendingList) ?> pending</span>
  </div>
  <div class="section-body" style="padding:0">
    <?php foreach (array_slice($pendingList,0,5) as $p): ?>
    <div style="display:flex;align-items:center;gap:12px;padding:.85rem 1.4rem;border-bottom:1px solid var(--border)">
      <div style="flex:1;min-width:0">
        <div style="font-size:.875rem;font-weight:500"><?= htmlspecialchars($p['title']) ?></div>
        <div style="font-size:.75rem;color:var(--muted)"><?= htmlspecialchars($p['student_name']) ?> · <?= timeAgo($p['uploaded_at']) ?></div>
      </div>
      <div style="display:flex;gap:6px">
        <form method="POST" style="display:inline">
          <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
          <input type="hidden" name="action" value="approve_portfolio">
          <input type="hidden" name="portfolio_id" value="<?= $p['id'] ?>">
          <button class="btn btn-success btn-sm">✅ Approve</button>
        </form>
        <button onclick="openRejectModal(<?= $p['id'] ?>)" class="btn btn-danger btn-sm">❌ Reject</button>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if (count($pendingList) > 5): ?>
      <div style="padding:.75rem 1.4rem;text-align:center"><a href="?tab=pending" class="btn btn-ghost btn-sm">View all <?= count($pendingList) ?> pending →</a></div>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>

<!-- ── PENDING TAB ────────────────────────────────────────── -->
<?php elseif ($tab === 'pending'): ?>
<?php if (empty($pendingList)): ?>
  <div class="section"><div class="section-body" style="text-align:center;padding:3rem;color:var(--muted)">
    <div style="font-size:2.5rem;margin-bottom:.75rem">🎉</div>
    <div>No pending portfolios — you're all caught up!</div>
  </div></div>
<?php else: ?>
  <div style="font-size:.85rem;color:var(--muted);margin-bottom:1rem"><?= count($pendingList) ?> portfolio<?= count($pendingList)!=1?'s':'' ?> awaiting review</div>
  <div style="display:grid;gap:12px">
    <?php foreach ($pendingList as $p): ?>
    <div class="section">
      <div class="section-body">
        <div style="display:flex;align-items:flex-start;gap:14px;flex-wrap:wrap">
          <div style="flex:1;min-width:200px">
            <div style="font-family:'Syne',sans-serif;font-weight:700;font-size:1rem;margin-bottom:.25rem"><?= htmlspecialchars($p['title']) ?></div>
            <?php if ($p['description']): ?>
              <div style="font-size:.85rem;color:var(--muted);margin-bottom:.5rem"><?= htmlspecialchars($p['description']) ?></div>
            <?php endif; ?>
            <div style="display:flex;gap:1rem;font-size:.78rem;color:var(--muted);flex-wrap:wrap">
              <span>👤 <?= htmlspecialchars($p['student_name']) ?></span>
              <span>📧 <?= htmlspecialchars($p['student_email']) ?></span>
              <span>💾 <?= round($p['size_mb'],1) ?> MB</span>
              <span>📅 <?= date('M j, Y H:i', strtotime($p['uploaded_at'])) ?></span>
            </div>
            <?php if ($p['tags']): ?>
              <div style="margin-top:.5rem;display:flex;flex-wrap:wrap;gap:4px">
                <?php foreach (explode(',',$p['tags']) as $tag): ?>
                  <span style="font-size:.7rem;padding:2px 8px;background:rgba(108,99,255,0.12);color:#A78BFA;border-radius:20px"><?= htmlspecialchars(trim($tag)) ?></span>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
          </div>
          <div style="display:flex;gap:8px;flex-shrink:0;flex-wrap:wrap">
            <a href="<?= htmlspecialchars($p['public_url']) ?>" target="_blank" class="btn btn-ghost btn-sm">🔍 Preview</a>
            <form method="POST" style="display:inline">
              <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
              <input type="hidden" name="action" value="approve_portfolio">
              <input type="hidden" name="portfolio_id" value="<?= $p['id'] ?>">
              <button class="btn btn-success">✅ Approve</button>
            </form>
            <button onclick="openRejectModal(<?= $p['id'] ?>)" class="btn btn-danger">❌ Reject</button>
          </div>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<!-- ── STUDENTS TAB ───────────────────────────────────────── -->
<?php elseif ($tab === 'students'): ?>
<form method="GET">
  <input type="hidden" name="tab" value="students">
  <div class="filter-row" style="margin-bottom:1.25rem">
    <div class="search-bar" style="flex:1;max-width:280px">
      <svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
      <input type="text" name="search" placeholder="Search name or email..." value="<?= htmlspecialchars($search) ?>">
    </div>
    <select class="form-select" name="status" style="width:150px">
      <option value="">All Status</option>
      <option value="active"    <?= $statusFil==='active'?'selected':'' ?>>Active</option>
      <option value="suspended" <?= $statusFil==='suspended'?'selected':'' ?>>Suspended</option>
    </select>
    <button type="submit" class="btn btn-primary btn-sm">Filter</button>
    <?php if ($search||$statusFil): ?><a href="?tab=students" class="btn btn-ghost btn-sm">Clear</a><?php endif; ?>
  </div>
</form>
<div class="section">
  <div class="table-wrap">
    <table>
      <thead><tr>
        <th>Student</th><th>College</th><th>Portfolios</th><th>Storage</th><th>Status</th><th>Joined</th><th>Actions</th>
      </tr></thead>
      <tbody>
        <?php foreach ($studentsList as $s): ?>
        <tr>
          <td>
            <div style="font-weight:500"><?= htmlspecialchars($s['name']) ?></div>
            <div style="font-size:.75rem;color:var(--muted)"><?= htmlspecialchars($s['email']) ?></div>
          </td>
          <td style="color:var(--muted);font-size:.85rem">-</td>
          <td><span class="badge badge-info"><?= $s['active_portfolios'] ?></span></td>
          <td>
            <div style="font-size:.8rem;color:var(--muted);margin-bottom:3px"><?= round($s['used_mb']??0,1) ?>/<?= $s['limit_mb']??200 ?> MB</div>
            <div class="progress-bar" style="width:80px;height:4px">
              <div class="progress-fill" style="width:<?= min(100,round((($s['used_mb']??0)/($s['limit_mb']??200))*100)) ?>%;background:var(--primary)"></div>
            </div>
          </td>
          <td><span class="badge badge-<?= $s['status']==='active'?'success':'danger' ?>"><?= $s['status'] ?></span></td>
          <td style="color:var(--muted);font-size:.82rem"><?= date('M j, Y', strtotime($s['created_at'])) ?></td>
          <td>
            <?php if ($s['status'] === 'active'): ?>
            <form method="POST" style="display:inline" onsubmit="return confirm('Suspend this student?')">
              <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
              <input type="hidden" name="action" value="suspend_student">
              <input type="hidden" name="student_id" value="<?= $s['id'] ?>">
              <button class="btn btn-danger btn-sm">Suspend</button>
            </form>
            <?php else: ?>
            <form method="POST" style="display:inline">
              <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
              <input type="hidden" name="action" value="activate_student">
              <input type="hidden" name="student_id" value="<?= $s['id'] ?>">
              <button class="btn btn-success btn-sm">Activate</button>
            </form>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($studentsList)): ?>
          <tr><td colspan="7" style="text-align:center;color:var(--muted);padding:2rem">No students found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- ── LOGS TAB ───────────────────────────────────────────── -->
<?php elseif ($tab === 'logs'): ?>
<div class="section">
  <div class="section-head"><span class="section-title">Activity Logs</span></div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>User</th><th>Action</th><th>Details</th><th>IP</th><th>Time</th></tr></thead>
      <tbody>
        <?php foreach ($logs as $log): ?>
        <tr>
          <td style="font-size:.85rem"><?= htmlspecialchars($log['user_name'] ?? 'System') ?></td>
          <td><span class="badge badge-info" style="font-family:var(--font-mono)"><?= htmlspecialchars($log['action']) ?></span></td>
          <td style="color:var(--muted);font-size:.82rem"><?= htmlspecialchars($log['details'] ?? '-') ?></td>
          <td style="color:var(--muted);font-size:.78rem;font-family:var(--font-mono)"><?= htmlspecialchars($log['ip_address']) ?></td>
          <td style="color:var(--muted);font-size:.78rem"><?= timeAgo($log['created_at']) ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($logs)): ?>
          <tr><td colspan="5" style="text-align:center;color:var(--muted);padding:2rem">No activity logs yet.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<!-- Reject Modal -->
<div class="modal-overlay" id="rejectModal">
  <div class="modal">
    <div class="modal-title">❌ Reject Portfolio</div>
    <form method="POST">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
      <input type="hidden" name="action" value="reject_portfolio">
      <input type="hidden" name="portfolio_id" id="rejectPortfolioId">
      <div class="form-group">
        <label class="form-label">Reason for Rejection</label>
        <textarea class="form-textarea" name="reason" placeholder="Explain why this portfolio is being rejected...">Does not meet quality standards.</textarea>
      </div>
      <div class="modal-footer">
        <button type="button" onclick="closeModal('rejectModal')" class="btn btn-ghost">Cancel</button>
        <button type="submit" class="btn btn-danger">Reject Portfolio</button>
      </div>
    </form>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-count]').forEach(el => {
    const t = parseInt(el.dataset.count);
    let c = 0; const iv = setInterval(() => { c=Math.min(c+Math.ceil(t/25),t); el.textContent=c; if(c>=t)clearInterval(iv); }, 50);
  });
});
function openRejectModal(portfolioId) {
  document.getElementById('rejectPortfolioId').value = portfolioId;
  openModal('rejectModal');
}
</script>
<?php dashboardClose(); ?>
