<?php
// ============================================================
// App Configuration
// ============================================================

define('APP_NAME', 'PortfolioHost');
define('APP_URL', 'http://localhost/portfolio-host'); // Change to your domain
define('APP_VERSION', '1.0.0');

// Storage limits
define('MAX_STORAGE_MB', 200);
define('MAX_ZIP_SIZE_MB', 200);
define('MAX_ZIP_FILES', 500);

// Session
define('SESSION_LIFETIME', 3600 * 24); // 24 hours

// Dashboard routes per role
define('ROLE_DASHBOARDS', [
    'student'   => '/dashboard/student.php',
    'recruiter' => '/dashboard/recruiter.php',
    'moderator' => '/dashboard/moderator.php',
    'admin'     => '/dashboard/admin.php',
]);

// Start session globally
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => SESSION_LIFETIME,
        'secure'   => false, // Set true in production with HTTPS
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    session_start();
}
