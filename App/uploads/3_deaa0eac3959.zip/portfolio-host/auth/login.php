<?php
require_once __DIR__ . '/../includes/auth_helper.php';

// Redirect if already logged in
if (isLoggedIn()) {
    $dash = ROLE_DASHBOARDS[$_SESSION['role']];
    header('Location: ' . APP_URL . $dash); exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    if (!$email || !$password) {
        $error = 'Please fill in all fields.';
    } else {
        $result = loginUser($email, $password);
        if ($result['success']) {
            header('Location: ' . $result['redirect']); exit;
        } else {
            $error = $result['message'];
        }
    }
}
$urlError = $_GET['error'] ?? '';
if ($urlError === 'unauthorized') $error = 'You do not have permission to access that page.';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign In — PortfolioHost</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --bg:       #080B14;
    --surface:  #0F1422;
    --border:   rgba(255,255,255,0.07);
    --primary:  #6C63FF;
    --primary2: #8B5CF6;
    --text:     #E8E8F0;
    --muted:    #6B6F80;
    --success:  #10B981;
    --danger:   #EF4444;
    --radius:   14px;
  }

  body {
    font-family: 'DM Sans', sans-serif;
    background: var(--bg);
    color: var(--text);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 1.5rem;
    position: relative;
    overflow: hidden;
  }

  /* Animated background blobs */
  body::before, body::after {
    content: '';
    position: fixed;
    border-radius: 50%;
    filter: blur(80px);
    opacity: 0.18;
    animation: float 8s ease-in-out infinite;
    pointer-events: none;
  }
  body::before {
    width: 500px; height: 500px;
    background: var(--primary);
    top: -150px; left: -150px;
  }
  body::after {
    width: 400px; height: 400px;
    background: #EC4899;
    bottom: -100px; right: -100px;
    animation-delay: -4s;
  }
  @keyframes float {
    0%,100% { transform: translate(0,0) scale(1); }
    50%      { transform: translate(30px,20px) scale(1.05); }
  }

  .card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 20px;
    width: 100%;
    max-width: 440px;
    padding: 2.5rem;
    position: relative;
    z-index: 1;
    backdrop-filter: blur(20px);
    animation: slideUp 0.5s cubic-bezier(0.16,1,0.3,1) both;
  }
  @keyframes slideUp {
    from { opacity:0; transform: translateY(30px); }
    to   { opacity:1; transform: translateY(0); }
  }

  .logo {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 2rem;
  }
  .logo-icon {
    width: 40px; height: 40px;
    background: linear-gradient(135deg, var(--primary), var(--primary2));
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
  }
  .logo-text {
    font-family: 'Syne', sans-serif;
    font-weight: 700;
    font-size: 1.15rem;
    letter-spacing: -0.02em;
  }

  .heading {
    font-family: 'Syne', sans-serif;
    font-size: 1.7rem;
    font-weight: 800;
    letter-spacing: -0.03em;
    margin-bottom: 0.4rem;
  }
  .sub {
    color: var(--muted);
    font-size: 0.9rem;
    margin-bottom: 2rem;
  }

  .field { margin-bottom: 1.2rem; }
  label {
    display: block;
    font-size: 0.82rem;
    font-weight: 500;
    color: var(--muted);
    margin-bottom: 0.45rem;
    letter-spacing: 0.03em;
    text-transform: uppercase;
  }
  input {
    width: 100%;
    background: rgba(255,255,255,0.04);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 0.82rem 1rem;
    color: var(--text);
    font-family: 'DM Sans', sans-serif;
    font-size: 0.95rem;
    outline: none;
    transition: border-color 0.2s, box-shadow 0.2s;
  }
  input:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(108,99,255,0.15);
  }

  .btn {
    width: 100%;
    padding: 0.9rem;
    background: linear-gradient(135deg, var(--primary), var(--primary2));
    color: #fff;
    border: none;
    border-radius: 10px;
    font-family: 'Syne', sans-serif;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    margin-top: 0.5rem;
    letter-spacing: 0.01em;
    transition: opacity 0.2s, transform 0.15s;
    position: relative;
    overflow: hidden;
  }
  .btn:hover  { opacity: 0.9; transform: translateY(-1px); }
  .btn:active { transform: translateY(0); opacity: 0.85; }

  .alert {
    background: rgba(239,68,68,0.1);
    border: 1px solid rgba(239,68,68,0.3);
    color: #FCA5A5;
    border-radius: 10px;
    padding: 0.75rem 1rem;
    font-size: 0.875rem;
    margin-bottom: 1.2rem;
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .divider {
    display: flex;
    align-items: center;
    gap: 12px;
    margin: 1.5rem 0;
    color: var(--muted);
    font-size: 0.8rem;
  }
  .divider::before, .divider::after {
    content: '';
    flex: 1;
    height: 1px;
    background: var(--border);
  }

  .link-row {
    text-align: center;
    color: var(--muted);
    font-size: 0.875rem;
    margin-top: 1.5rem;
  }
  .link-row a {
    color: var(--primary);
    text-decoration: none;
    font-weight: 500;
  }
  .link-row a:hover { text-decoration: underline; }

  /* Demo accounts */
  .demo-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
    margin-top: 1rem;
  }
  .demo-btn {
    padding: 0.55rem 0.75rem;
    background: rgba(255,255,255,0.04);
    border: 1px solid var(--border);
    border-radius: 8px;
    color: var(--text);
    font-size: 0.8rem;
    cursor: pointer;
    transition: background 0.15s, border-color 0.15s;
    text-align: left;
  }
  .demo-btn:hover { background: rgba(108,99,255,0.12); border-color: var(--primary); }
  .demo-role { display: block; font-weight: 600; font-size: 0.75rem; color: var(--primary); margin-bottom: 1px; text-transform: uppercase; letter-spacing: 0.04em; }

  /* Password toggle */
  .pass-wrap { position: relative; }
  .pass-wrap input { padding-right: 2.8rem; }
  .pass-toggle {
    position: absolute; right: 12px; top: 50%;
    transform: translateY(-50%);
    background: none; border: none; cursor: pointer;
    color: var(--muted); padding: 4px;
  }
  .pass-toggle:hover { color: var(--text); }
</style>
</head>
<body>

<div class="card">
  <div class="logo">
    <div class="logo-icon">🎯</div>
    <span class="logo-text">PortfolioHost</span>
  </div>

  <h1 class="heading">Welcome back</h1>
  <p class="sub">Sign in to your account to continue</p>

  <?php if ($error): ?>
  <div class="alert">
    <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
    <?= htmlspecialchars($error) ?>
  </div>
  <?php endif; ?>

  <form method="POST" action="">
    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">

    <div class="field">
      <label for="email">Email Address</label>
      <input type="email" id="email" name="email" placeholder="you@example.com"
             value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required autofocus>
    </div>

    <div class="field">
      <label for="password">Password</label>
      <div class="pass-wrap">
        <input type="password" id="password" name="password" placeholder="Enter your password" required>
        <button type="button" class="pass-toggle" onclick="togglePass()">
          <svg id="eye-icon" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
            <circle cx="12" cy="12" r="3"/>
          </svg>
        </button>
      </div>
    </div>

    <button type="submit" class="btn">Sign In →</button>
  </form>

  <div class="divider">quick demo access</div>

  <div class="demo-grid">
    <button class="demo-btn" onclick="fillDemo('admin@portfoliohost.com')">
      <span class="demo-role">Admin</span>admin@portfoliohost.com
    </button>
    <button class="demo-btn" onclick="fillDemo('mod@portfoliohost.com')">
      <span class="demo-role">Moderator</span>mod@portfoliohost.com
    </button>
    <button class="demo-btn" onclick="fillDemo('recruiter@portfoliohost.com')">
      <span class="demo-role">Recruiter</span>recruiter@portfoliohost.com
    </button>
    <button class="demo-btn" onclick="fillDemo('student@portfoliohost.com')">
      <span class="demo-role">Student</span>student@portfoliohost.com
    </button>
  </div>

  <p class="link-row">
    Don't have an account? <a href="register.php">Create one free</a>
  </p>
</div>

<script>
function fillDemo(email) {
  document.getElementById('email').value = email;
  document.getElementById('password').value = 'password';
  document.getElementById('email').closest('form').querySelector('[type=submit]').focus();
}
function togglePass() {
  const p = document.getElementById('password');
  p.type = p.type === 'password' ? 'text' : 'password';
}
</script>
</body>
</html>
