<?php
require_once __DIR__ . '/../includes/auth_helper.php';
if (isLoggedIn()) {
    logActivity($_SESSION['user_id'], 'logout', 'User logged out');
}
session_destroy();
header('Location: ' . APP_URL . '/auth/login.php');
exit;
