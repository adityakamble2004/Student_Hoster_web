# PortfolioHost — Setup Guide
## Quick Start (XAMPP / WAMP)

### Step 1 — Place the project
Copy the `portfolio-host/` folder into:
- XAMPP: `C:/xampp/htdocs/portfolio-host/`
- WAMP:  `C:/wamp64/www/portfolio-host/`

### Step 2 — Create the database
1. Open phpMyAdmin → `http://localhost/phpmyadmin`
2. Click **New** → name it `portfolio_host` → Create
3. Click **Import** → select `database.sql` → Go

### Step 3 — Configure the database
Edit `config/database.php`:
```php
define('DB_USER', 'root');   // your MySQL username
define('DB_PASS', '');       // your MySQL password (blank for XAMPP default)
```

### Step 4 — Configure the app URL
Edit `config/config.php`:
```php
define('APP_URL', 'http://localhost/portfolio-host');
```

### Step 5 — Set folder permissions
Make sure `uploads/` and `public/portfolios/` are writable.

### Step 6 — Open the app
Go to: `http://localhost/portfolio-host/`

---

## Demo Login Accounts
All accounts use password: **password**

| Role       | Email                         |
|------------|-------------------------------|
| Admin      | admin@portfoliohost.com       |
| Moderator  | mod@portfoliohost.com         |
| Recruiter  | recruiter@portfoliohost.com   |
| Student    | student@portfoliohost.com     |

> ⚠️ Change all passwords immediately after first login!

---

## File Structure
```
portfolio-host/
├── config/
│   ├── database.php       ← DB credentials
│   └── config.php         ← App settings
├── auth/
│   ├── login.php          ← Login page
│   ├── register.php       ← Registration
│   └── logout.php         ← Logout handler
├── dashboard/
│   ├── student.php        ← Student dashboard
│   ├── recruiter.php      ← Recruiter dashboard
│   ├── moderator.php      ← Moderator dashboard
│   └── admin.php          ← Admin dashboard
├── includes/
│   ├── auth_helper.php    ← Session + auth functions
│   └── dashboard_layout.php ← Shared UI layout
├── public/
│   └── portfolios/        ← Hosted student portfolios go here
├── uploads/               ← Temp ZIP uploads (auto-deleted)
├── database.sql           ← Full DB schema
├── index.php              ← Entry point (auto-redirects)
└── .htaccess              ← Apache security rules
```
