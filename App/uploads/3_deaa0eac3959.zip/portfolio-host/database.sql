-- ============================================================
-- PortfolioHost - Database Schema
-- Run this in phpMyAdmin or MySQL CLI
-- ============================================================

CREATE DATABASE IF NOT EXISTS portfolio_host CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE portfolio_host;

-- Users table (all roles)
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('student','recruiter','moderator','admin') NOT NULL DEFAULT 'student',
    status ENUM('active','suspended','pending') NOT NULL DEFAULT 'active',
    avatar VARCHAR(500) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Student profiles (extra info for students)
CREATE TABLE student_profiles (
    student_id INT PRIMARY KEY,
    bio TEXT,
    skills VARCHAR(1000),
    college VARCHAR(200),
    grad_year YEAR,
    github_url VARCHAR(300),
    linkedin_url VARCHAR(300),
    resume_path VARCHAR(500),
    FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Portfolios
CREATE TABLE portfolios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    folder_path VARCHAR(500) NOT NULL,
    public_url VARCHAR(500) NOT NULL,
    size_mb DECIMAL(8,2) DEFAULT 0,
    status ENUM('pending','active','rejected') DEFAULT 'pending',
    visibility ENUM('public','private') DEFAULT 'public',
    rejection_reason TEXT DEFAULT NULL,
    tags VARCHAR(500),
    views INT DEFAULT 0,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Storage usage per student
CREATE TABLE storage_usage (
    student_id INT PRIMARY KEY,
    used_mb DECIMAL(8,2) DEFAULT 0,
    limit_mb INT DEFAULT 200,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Recruiter bookmarks
CREATE TABLE bookmarks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    recruiter_id INT NOT NULL,
    portfolio_id INT NOT NULL,
    note TEXT,
    saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_bookmark (recruiter_id, portfolio_id),
    FOREIGN KEY (recruiter_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE
);

-- Activity logs
CREATE TABLE activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action VARCHAR(255) NOT NULL,
    details TEXT,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Notifications
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('info','success','warning','danger') DEFAULT 'info',
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Password reset tokens
CREATE TABLE password_resets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(150) NOT NULL,
    token VARCHAR(255) NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    used TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Portfolio views tracking
CREATE TABLE portfolio_views (
    id INT AUTO_INCREMENT PRIMARY KEY,
    portfolio_id INT NOT NULL,
    viewer_ip VARCHAR(45),
    viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE
);

-- ============================================================
-- Seed: Default admin account
-- Password: Admin@1234
-- ============================================================
INSERT INTO users (name, email, password, role, status) VALUES
('Super Admin', 'admin@portfoliohost.com', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active'),
('Test Moderator', 'mod@portfoliohost.com', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'moderator', 'active'),
('Test Recruiter', 'recruiter@portfoliohost.com', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'recruiter', 'active'),
('Aditya Kamble', 'student@portfoliohost.com', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 'active');

-- Note: Default password for all seed accounts is "password"
-- Change immediately after first login!
